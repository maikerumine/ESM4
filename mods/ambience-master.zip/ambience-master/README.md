Ambience Lite mod for Minetest

Based on Immersive Sounds .36 mod by Neuromancer and optimized to run on servers with new fire sounds added when Fire Redo mod is detected...

0.1 - Initial release
0.2 - Code change and new water sounds added
0.3 - Works with Fire Redo mod to provide fire sounds
0.4 - Code optimized
0.5 - Changed to kilbiths smaller sound files and removed canadianloon1, adjusted timings
0.6 - Using new find_nodes_in_area features to count nodes and speed up execution (thanks everamzah)
