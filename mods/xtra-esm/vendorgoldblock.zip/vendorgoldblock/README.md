vendorgoldblock
======

Minetest mod:  Goldblock Vending machines