Licenses: code LGPL 2.1 media CC BY-SA 3.0
Version: 1
Name: smartshop
Created by: UjEdwin


Like the title says, this is a smart and easy shop, that will also fit everywhere.

it is a mix of a vending machine, a shop, item frames and light.

You can toogle it unlimited or limited if you have give or creative
(unlimited will not take or add stuff to its inventory)

It also works with pipeworks