--mt_seasons v0.2
--maikerumine
--made forMinetest Game
--License for code lgpl-2.1
mt_seasons = {}
mt_seasons.SETTING = 5;


-----------------------------------------------------------------------------
--SEASONS
-----------------------------------------------------------------------------
--	1 == Spring		Early plant growth and budding flowers.
--	2 == Summer		Default - As if mod wasn't installed.
--	3 == Autumn		Autumn colors and yellowing plantlife.
--	4 == Winter		Snow and ice and dead trees.
--	5 == Fire World  		Halloween dark themed.
--	6 == Stone world		An all stone world.  [Works on new map chunks only, irreversable.]
--	7 == Christmas 		A Christmas winter wonderland world.
--	8== Cobble! 		LOL.
--	9== Snow and Ice! 	Must Test like.










