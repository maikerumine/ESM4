-- Minetest 0.4 mod: holiday
-- 
-- See README.txt for licensing and other information.

