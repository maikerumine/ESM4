    --Version 0.2
    --by emperor_genshin
    --modified for ESM game by: maikerumine
    --https://forum.minetest.net/viewtopic.php?f=9&t=13775&hilit=[mod]skybox


	-- speed, jump, gravity, sneak, sneak_glitch, new_move

    pos = {x=0, y=0, z=0}

    local space = 5000 --value for space, change the value to however you like.
    local cave = -40 --value for cave, change the value to however you like.

    --The skybox for space, feel free to change it to however you like.
    local spaceskybox = {
    "sky_pos_y.png",
    "sky_neg_y.png",
    "sky_pos_z.png",
    "sky_neg_z.png",
    "sky_neg_x.png",
    "sky_pos_x.png",
    }
    local caveskybox = {
    "black.png",
    "black.png",
    "black.png",
    "black.png",
    "black.png",
    "black.png",
    }
	local ThickCloudsWater = {
	"ThickCloudsWaterUp.jpg",
	"ThickCloudsWaterDown.jpg",
	"ThickCloudsWaterFront.jpg",
	"ThickCloudsWaterBack.jpg",
	"ThickCloudsWaterLeft.jpg",
	"ThickCloudsWaterRight.jpg",
    }

local time = 0
minetest.register_globalstep(function(dtime)
		time = time + dtime
		if time > 0 then for _, player in ipairs(minetest.get_connected_players()) do
		time = 0

		local name = player:get_player_name()
		local pos = player:getpos()
	
	    --If the player has reached Space
		if minetest.get_player_by_name(name) and pos.y >= space then
			player:set_physics_override({gravity = 0.2,}) 
			player:set_sky({
				base_color = "blue",
				type = "skybox",
				textures = spaceskybox,
				clouds = false
			})
		    --If the player is on Earth
			elseif minetest.get_player_by_name(name) and pos.y < space then
				player:set_physics_override({gravity = 1,})
				player:set_sky({
					base_color = "white",
					type = "regular",
					--type = "skybox",
					--textures = ThickCloudsWater,
					{},
					clouds = true
				})
			    --If the player has reached Cave
				if minetest.get_player_by_name(name) and pos.y <=cave then
				player:set_physics_override({gravity = 1.2,})
				player:set_sky({
					base_color = "black",
					type = "skybox",
					textures = caveskybox,
					clouds = false
				})
				end
			end
		end
	end
end)

minetest.register_on_leaveplayer(function(player)
	local name = player:get_player_name()
		if name then
			player:set_sky({
			base_color = "white",
			type = "regular",
			{},
			clouds = true
		})
	end
end)
