
MONSTER MOBS

Dirt Monster

- Spawning at night on green grass (or grey in ethereal) these mobs wander around looking for a player to eat. Drops 1-5 dirt when killed.

Dungeon Master

- Spawning below -70 underground DM's have a tendency to hurl fire balls at unsuspecting players and can cause major damage, but get too close and he will switch to dogfight attack. Can drop mese or diamond when killed.

Lava Flan

- Cute as they may look lava flan wallow in their namesake (no, not flans) and get curious about players who wander by, forgetting that they can burn you and cause damage. They have a 1 in 5 chance of dropping lava orb when killed.

Mese Monster

- These mobs are territorial and spawn below -20 and will fire mese shards at passers by, so best avoided. Will drop mese when killed.

Oerkki

- Found in dark areas like most monsters Oerkki wander the caverns stealing away torches on the ground and attacking anyone found in that area. 1 in 3 chance of dropping obsidian.

Sand Monster

- The hot deserts are home to these guys who spawn at any time of the day to attack players. They drop 3-5 desert sand when killed.

Spider

- Found in dark holes inside desertstone (crystal biomes in ethereal), spiders wait for prey to amble past and strike. They are mostly docile during the day though unless hit. Will drop string when killed.

Stone Monster

- Found underground in dark caves these mobs seem to be zombie-like in fashion with a tendency to rush a player in the area. can drop torch, iron or coal when killed.

Tree Monster

- Found atop tree's at night time they drop down and look for food in the form of players. Can drop saplings and sometimes an apple or three.
