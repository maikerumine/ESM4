--Extreme Survival created by maikerumine
-- Minetest 0.4.13 mod: "Extreme Survival"
-- namespace: es
--version 1.8
--https://github.com/maikerumine

--License:
--~~~~~~~~
--Code:
--(c) Copyright 2015 maikerumine; modified zlib-License
--see "LICENSE.txt" for details.

--Media(if not stated differently):
--(c) Copyright (2014-2015) maikerumine; CC-BY-SA 3.0

--Alias                      "old"--->"new"
------------------------------------------




--vendor
minetest.register_alias("es:stone_with_emerald", "default:stone_with_iron")
minetest.register_alias("es:stone_with_ruby", "default:stone_with_copper")
minetest.register_alias("es:stone_with_aikerum", "default:stone_with_diamond")
minetest.register_alias("es:stone_with_infinium", "default:stone_with_mese")
minetest.register_alias("es:stone_with_purpellium", "default:stone_with_coal")
minetest.register_alias("es:depleted_uranium", "default:stone_with_gold")




minetest.register_alias("esmobs:cursed_stone", "default:goldblock")




