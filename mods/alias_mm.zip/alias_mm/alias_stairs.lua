-- mods/default/aliases_stairs.lua

-- MASSIVE overwrite to old nodes and items merged into default


-- S T A I R S --
--mainly invcorner to corner inner / outer







--=================================

-- Register default stairs and slabs
--	"default:wood",
        minetest.register_alias("stairs:invcorner_wood", "stairs:stair_inner_wood")
        minetest.register_alias("stairs:corner_wood", "stairs:stair_outer_wood")
--	"default:junglewood",
        minetest.register_alias("stairs:invcorner_junglewood", "stairs:stair_inner_junglewood")
        minetest.register_alias("stairs:corner_junglewood", "stairs:stair_outer_junglewood")
--	"default:pine_wood",
        minetest.register_alias("stairs:invcorner_pine_wood", "stairs:stair_inner_pine_wood")
        minetest.register_alias("stairs:corner_pine_wood", "stairs:stair_outer_pine_wood")
--	"default:acacia_wood",
        minetest.register_alias("stairs:invcorner_acacia_wood", "stairs:stair_inner_acacia_wood")
        minetest.register_alias("stairs:corner_acacia_wood", "stairs:stair_outer_acacia_wood")
--	"default:aspen_wood",
        minetest.register_alias("stairs:invcorner_aspen_wood", "stairs:stair_inner_aspen_wood")
        minetest.register_alias("stairs:corner_aspen_wood", "stairs:stair_outer_aspen_wood")

--	"default:stone",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")

--	"default:cobble",
        minetest.register_alias("stairs:invcorner_cobble", "stairs:stair_inner_cobble")
        minetest.register_alias("stairs:corner_cobble", "stairs:stair_outer_cobble")
--	"default:mossycobble",
        minetest.register_alias("stairs:invcorner_mossycobble", "stairs:stair_inner_mossycobble")
        minetest.register_alias("stairs:corner_mossycobble", "stairs:stair_outer_mossycobble")
--	"default:stonebrick",
        minetest.register_alias("stairs:invcorner_stonebrick", "stairs:stair_inner_stonebrick")
        minetest.register_alias("stairs:corner_stonebrick", "stairs:stair_outer_stonebrick")
--	"default:stone_block",
        minetest.register_alias("stairs:invcorner_stone_block", "stairs:stair_inner_stone_block")
        minetest.register_alias("stairs:corner_stone_block", "stairs:stair_outer_stone_block")
--	"default:desert_stone",
        minetest.register_alias("stairs:invcorner_desert_stone", "stairs:stair_inner_desert_stone")
        minetest.register_alias("stairs:corner_desert_stone", "stairs:stair_outer_desert_stone")
--	"default:desert_cobble",
        minetest.register_alias("stairs:invcorner_desert_cobble", "stairs:stair_inner_desert_cobble")
        minetest.register_alias("stairs:corner_desert_cobble", "stairs:stair_outer_desert_cobble")
--	"default:desert_stonebrick",
        minetest.register_alias("stairs:invcorner_desert_stonebrick", "stairs:stair_inner_desert_stonebrick")
        minetest.register_alias("stairs:corner_desert_stonebrick", "stairs:stair_outer_desert_stonebrick")
--	"default:desert_stone_block",
        minetest.register_alias("stairs:invcorner_desert_stone_block", "stairs:stair_inner_desert_stone_block")
        minetest.register_alias("stairs:corner_desert_stone_block", "stairs:stair_outer_desert_stone_block")
--	"default:sandstone",
        minetest.register_alias("stairs:invcorner_sandstone", "stairs:stair_inner_sandstone")
        minetest.register_alias("stairs:corner_sandstone", "stairs:stair_outer_sandstone")
--	"default:sandstonebrick",
        minetest.register_alias("stairs:invcorner_sandstonebrick", "stairs:stair_inner_sandstonebrick")
        minetest.register_alias("stairs:corner_sandstonebrick", "stairs:stair_outer_sandstonebrick")
--	"default:sandstone_block",
        minetest.register_alias("stairs:invcorner_sandstone_block", "stairs:stair_inner_sandstone_block")
        minetest.register_alias("stairs:corner_sandstone_block", "stairs:stair_outer_sandstone_block")
--	"default:desert_sandstone",
        minetest.register_alias("stairs:invcorner_desert_sandstone", "stairs:stair_inner_desert_sandstone")
        minetest.register_alias("stairs:corner_desert_sandstone", "stairs:stair_outer_desert_sandstone")
--	"default:desert_sandstone_brick",
        minetest.register_alias("stairs:invcorner_desert_sandstone_brick", "stairs:stair_inner_desert_sandstone_brick")
        minetest.register_alias("stairs:corner_desert_sandstone_brick", "stairs:stair_outer_desert_sandstone_brick")
--	"default:desert_sandstone_block",
        minetest.register_alias("stairs:invcorner_desert_sandstone_block", "stairs:stair_inner_desert_sandstone_block")
        minetest.register_alias("stairs:corner_desert_sandstone_block", "stairs:stair_outer_desert_sandstone_block")
--	"default:silver_sandstone",
        minetest.register_alias("stairs:invcorner_silver_sandstone", "stairs:stair_inner_silver_sandstone")
        minetest.register_alias("stairs:corner_silver_sandstone", "stairs:stair_outer_silver_sandstone")
--	"default:silver_sandstone_brick",
        minetest.register_alias("stairs:invcorner_silver_sandstone_brick", "stairs:stair_inner_silver_sandstone_brick")
        minetest.register_alias("stairs:corner_silver_sandstone_brick", "stairs:stair_outer_silver_sandstone_brick")
--	"default:silver_sandstone_block",
        minetest.register_alias("stairs:invcorner_silver_sandstone_block", "stairs:stair_inner_silver_sandstone_block")
        minetest.register_alias("stairs:corner_silver_sandstone_block", "stairs:stair_outer_silver_sandstone_block")
--	"default:obsidian",
        minetest.register_alias("stairs:invcorner_obsidian", "stairs:stair_inner_obsidian")
        minetest.register_alias("stairs:corner_obsidian", "stairs:stair_outer_obsidian")
--	"default:obsidianbrick",
        minetest.register_alias("stairs:invcorner_obsidianbrick", "stairs:stair_inner_obsidianbrick")
        minetest.register_alias("stairs:corner_obsidianbrick", "stairs:stair_outer_obsidianbrick")
--	"default:obsidian_block",
        minetest.register_alias("stairs:invcorner_obsidian_block", "stairs:stair_inner_obsidian_block")
        minetest.register_alias("stairs:corner_obsidian_block", "stairs:stair_outer_obsidian_block")
--	"default:brick",
        minetest.register_alias("stairs:invcorner_brick", "stairs:stair_inner_brick")
        minetest.register_alias("stairs:corner_brick", "stairs:stair_outer_brick")
--	"default:steelblock",
        minetest.register_alias("stairs:invcorner_steelblock", "stairs:stair_inner_steelblock")
        minetest.register_alias("stairs:corner_steelblock", "stairs:stair_outer_steelblock")
--	"default:tinblock",
        minetest.register_alias("stairs:invcorner_tinblock", "stairs:stair_inner_tinblock")
        minetest.register_alias("stairs:corner_tinblock", "stairs:stair_outer_tinblock")
--	"default:copperblock",
        minetest.register_alias("stairs:invcorner_copperblock", "stairs:stair_inner_copperblock")
        minetest.register_alias("stairs:corner_copperblock", "stairs:stair_outer_copperblock")
--	"default:bronzeblock",
        minetest.register_alias("stairs:invcorner_bronzeblock", "stairs:stair_inner_bronzeblock")
        minetest.register_alias("stairs:corner_bronzeblock", "stairs:stair_outer_bronzeblock")
--	"default:goldblock",
        minetest.register_alias("stairs:invcorner_goldblock", "stairs:stair_inner_goldblock")
        minetest.register_alias("stairs:corner_goldblock", "stairs:stair_outer_goldblock")
--	"default:diamindblock",
        minetest.register_alias("stairs:invcorner_diamindblock", "stairs:stair_inner_diamindblock")
        minetest.register_alias("stairs:corner_diamindblock", "stairs:stair_outer_diamindblock")
--	"default:mese",
        minetest.register_alias("stairs:invcorner_mese", "stairs:stair_inner_mese")
        minetest.register_alias("stairs:corner_mese", "stairs:stair_outer_mese")
--	"default:ice",
        minetest.register_alias("stairs:invcorner_ice", "stairs:stair_inner_ice")
        minetest.register_alias("stairs:corner_ice", "stairs:stair_outer_ice")
--	"default:snowblock",
        minetest.register_alias("stairs:invcorner_snowblock", "stairs:stair_inner_snowblock")
        minetest.register_alias("stairs:corner_snowblock", "stairs:stair_outer_snowblock")


--Extreme Survival Extra Nodes and more custom default nodes
--============================
--============================
--trees
--	"default:tree",
        minetest.register_alias("stairs:invcorner_tree", "stairs:stair_inner_tree")
        minetest.register_alias("stairs:corner_tree", "stairs:stair_outer_tree")
--  "default:jungletree",
        minetest.register_alias("stairs:invcorner_jungletree", "stairs:stair_inner_jungletree")
        minetest.register_alias("stairs:corner_jungletree", "stairs:stair_outer_jungletree")
--  "default:pine_tree",
        minetest.register_alias("stairs:invcorner_pine_tree", "stairs:stair_inner_pine_tree")
        minetest.register_alias("stairs:corner_pine_tree", "stairs:stair_outer_pine_tree")
--  "default:acacia_tree",
        minetest.register_alias("stairs:invcorner_acacia_tree", "stairs:stair_inner_acacia_tree")
        minetest.register_alias("stairs:corner_acacia_tree", "stairs:stair_outer_acacia_tree") 
--  "default:aspen_tree",
        minetest.register_alias("stairs:invcorner_aspen_tree", "stairs:stair_inner_aspen_tree")
        minetest.register_alias("stairs:corner_aspen_tree", "stairs:stair_outer_aspen_tree")


--dirts
--	"default:clay",
    minetest.register_alias("stairs:stair_Clay", "stairs:stair_clay")
	
--	"default:dirt",
    minetest.register_alias("stairs:stair_Dirt", "stairs:stair_dirt")

--	"default:dry_dirt",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--	"default:dirt_with_grass",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
    minetest.register_alias("es:stair_dirt_with_grass", "stairs:stair_dirt_with_grass")

--	"default:dirt_with_snow",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--	"default:dirt_with_dry_grass",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--	"default:dirt_with_rainforest_litter",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--	"default:dirt_with_coniferous_litter",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")


--colours for nodes	
--========================

local coloursg = {
	{"black",      "Black",      "#000000b0"},
	{"blue",       "Blue",       "#015dbb70"},
	{"brown",      "Brown",      "#a78c4570"},
	{"cyan",       "Cyan",       "#01ffd870"},
	{"dark_green", "Dark Green", "#005b0770"},
	{"dark_grey",  "Dark Grey",  "#303030b0"},
	{"green",      "Green",      "#61ff0170"},
	{"grey",       "Grey",       "#5b5b5bb0"},
	{"magenta",    "Magenta",    "#ff05bb70"},
	{"orange",     "Orange",     "#ff840170"},
	{"pink",       "Pink",       "#ff65b570"},
	{"red",        "Red",        "#ff000070"},
	{"violet",     "Violet",     "#2000c970"},
	{"white",      "White",      "#abababc0"},
	{"yellow",     "Yellow",     "#e3ff0070"},
}

local colours = {
	{"black",      "Black",      "cblocks_black.png"},
	{"blue",       "Blue",       "cblocks_blue.png"},
	{"brown",      "Brown",      "cblocks_brown.png"},
	{"cyan",       "Cyan",       "cblocks_cyan.png"},
	{"dark_green", "Dark Green", "cblocks_dark_green.png"},
	{"dark_grey",  "Dark Grey",  "cblocks_dark_grey.png"},
	{"green",      "Green",      "cblocks_green.png"},
	{"grey",       "Grey",       "cblocks_grey.png"},
	{"magenta",    "Magenta",    "cblocks_magenta.png"},
	{"orange",     "Orange",     "cblocks_orange.png"},
	{"pink",       "Pink",       "cblocks_pink.png"},
	{"red",        "Red",        "cblocks_red.png"},
	{"violet",     "Violet",     "cblocks_violet.png"},
	{"white",      "White",      "cblocks_white.png"},
	{"yellow",     "Yellow",     "cblocks_yellow.png"},
}
--= Coloured Blocks Mod
if minetest.get_modpath("cblocks") then
	for i = 1, #colours, 1 do

--		"cblocks:stonebrick_" .. colours[i][1],
--		"cblocks:brick_" .. colours[i][1],
--		"cblocks:stone_" .. colours[i][1],
--		"cblocks:clay_" .. colours[i][1],
--		"cblocks:wood_" .. colours[i][1],
--		"cblocks:cobble_" .. colours[i][1],
--		"cblocks:glass_" .. colours[i][1],
--		"cblocks:meselamp_" .. colours[i][1],

	end --for
end


--= Wool Mod

if minetest.get_modpath("wool") then
	for i = 1, #colours, 1 do
		--"wool:" .. colours[i][1],
	end -- END for
end


--= Es Mod
if minetest.get_modpath("es") then

	--es grass
--		"es:dry_dirt",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_grass",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:aiden_grass",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")


	--ES Technic marble / Granite
--		"es:granite",
        minetest.register_alias("stairs:invcorner_granite", "stairs:stair_inner_granite")
        minetest.register_alias("stairs:corner_granite", "stairs:stair_outer_granite")
--		"es:marble",
        minetest.register_alias("stairs:invcorner_marble", "stairs:stair_inner_marble")
        minetest.register_alias("stairs:corner_marble", "stairs:stair_outer_marble")
--		"es:granite_bricks",
        minetest.register_alias("stairs:invcorner_granite_bricks", "stairs:stair_inner_granite_bricks")
        minetest.register_alias("stairs:corner_granite_bricks", "stairs:stair_outer_granite_bricks")
--		"es:marble_bricks",
        minetest.register_alias("stairs:invcorner_marble_bricks", "stairs:stair_inner_marble_bricks")
        minetest.register_alias("stairs:corner_marble_bricks", "stairs:stair_outer_marble_bricks")


    --Es Strange Trees
--		"es:strange_tree",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_tree_wood",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:aiden_tree",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:aiden_tree_wood",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")


	--Es Strange Clay 
--		"es:strange_clay_blue",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_clay_red",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_clay_maroon",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_clay_brown",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_clay_orange",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_clay_black",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")
--		"es:strange_clay_grey",
        minetest.register_alias("stairs:invcorner_stone", "stairs:stair_inner_stone")
        minetest.register_alias("stairs:corner_stone", "stairs:stair_outer_stone")


	--Es Jewels
--		"es:emeraldblock",
        minetest.register_alias("stairs:invcorner_emeraldblock", "stairs:stair_inner_emeraldblock")
        minetest.register_alias("stairs:corner_emeraldblock", "stairs:stair_outer_emeraldblock")
--		"es:rubyblock",
        minetest.register_alias("es:stair_rubyblock", "stairs:stair_ruby")
        minetest.register_alias("stairs:stair_Ruby", "stairs:stair_ruby")
        minetest.register_alias("stairs:invcorner_ruby", "stairs:stair_inner_ruby")
        minetest.register_alias("stairs:corner_ruby", "stairs:stair_outer_ruby")
        minetest.register_alias("es:slab_rubyblock", "stairs:slab_ruby")
        minetest.register_alias("stairs:slab_Ruby", "stairs:slab_ruby")
        minetest.register_alias("es:slab1_rubyblock", "stairs:slab1_ruby")
        minetest.register_alias("es:slope_rubyblock", "stairs:slope_ruby")

--		"es:aikerumblock",
        minetest.register_alias("stairs:invcorner_aikerumblock", "stairs:stair_inner_aikerumblock")
        minetest.register_alias("stairs:corner_aikerumblock", "stairs:stair_outer_aikerumblock")
--		"es:infiniumblock",
        minetest.register_alias("stairs:invcorner_infiniumblock", "stairs:stair_inner_infiniumblock")
        minetest.register_alias("stairs:corner_infiniumblock", "stairs:stair_outer_infiniumblock")
--		"es:purpelliumblock",
        minetest.register_alias("stairs:invcorner_unobtaniumblock", "stairs:stair_inner_unobtaniumblock")
        minetest.register_alias("stairs:corner_unobtaniumblock", "stairs:stair_outer_unobtaniumblock")
--		"es:unobtaniumblock",
        minetest.register_alias("stairs:invcorner_unobtaniumblock", "stairs:stair_inner_unobtaniumblock")
        minetest.register_alias("stairs:corner_unobtaniumblock", "stairs:stair_outer_unobtaniumblock")
--		"es:depleted_uraniumblock",
        minetest.register_alias("stairs:invcorner_depleted_uraniumblock", "stairs:stair_inner_depleted_uraniumblock")
        minetest.register_alias("stairs:corner_depleted_uraniumblock", "stairs:stair_outer_depleted_uraniumblock")
--		"es:boneblock",
        minetest.register_alias("stairs:invcorner_boneblock", "stairs:stair_inner_boneblock")
        minetest.register_alias("stairs:corner_boneblock", "stairs:stair_outer_boneblock")
--		"es:messymese",
        minetest.register_alias("stairs:invcorner_messymese", "stairs:stair_inner_messymese")
        minetest.register_alias("stairs:corner_messymese", "stairs:stair_outer_messymese")
	
		
end

--lighted nodes
--	"default:meselamp",
        minetest.register_alias("stairs:invcorner_meselamp", "stairs:stair_inner_meselamp")
        minetest.register_alias("stairs:corner_meselamp", "stairs:stair_outer_meselamp")


--============================
--============================

-- Glass stair nodes need to be registered individually to utilize specialized textures.


--	"default:glass",
        minetest.register_alias("stairs:invcorner_glass", "stairs:stair_inner_glass")
        minetest.register_alias("stairs:corner_glass", "stairs:stair_outer_glass")

--	"default:obsidian_glass",
        minetest.register_alias("stairs:invcorner_obsidian_glass", "stairs:stair_inner_obsidian_glass")
        minetest.register_alias("stairs:corner_obsidian_glass", "stairs:stair_outer_obsidian_glass")



