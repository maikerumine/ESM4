-- mods/default/aliases_farming.lua

-- MASSIVE overwrite to old nodes and items merged into default

--farming:cotton_wild
--farming:cotton_seed
--F A R M I N G--

--barley
minetest.register_alias("farming:seed_barley", "farming:seed_wheat")
minetest.register_alias("farming:barley", "farming:seed_wheat")
minetest.register_alias("farming:barley_1", "farming:wheat_1")
minetest.register_alias("farming:barley_2", "farming:wheat_2")
minetest.register_alias("farming:barley_3", "farming:wheat_3")
minetest.register_alias("farming:barley_4", "farming:wheat_4")
minetest.register_alias("farming:barley_5", "farming:wheat_5")
minetest.register_alias("farming:barley_6", "farming:wheat_6")
minetest.register_alias("farming:barley_7", "farming:wheat_7")
minetest.register_alias("farming:barley_8", "farming:wheat_8")

--beans
minetest.register_alias("farming:beans", "farming:bread")
minetest.register_alias("farming:beanbush", "farming:cotton_wild")
minetest.register_alias("farming:beanpole", "farming:cotton_wild")
minetest.register_alias("farming:beanpole_1", "farming:cotton_wild")
minetest.register_alias("farming:beanpole_2", "farming:cotton_wild")
minetest.register_alias("farming:beanpole_3", "farming:cotton_wild")
minetest.register_alias("farming:beanpole_4", "farming:cotton_wild")
minetest.register_alias("farming:beanpole_5", "farming:cotton_wild")

--blueberries
minetest.register_alias("farming:blueberries", "farming:bread")
minetest.register_alias("farming:muffin_blueberry", "farming:bread")
minetest.register_alias("farming:blueberry_1", "farming:wheat_1")
minetest.register_alias("farming:blueberry_2", "farming:wheat_2")
minetest.register_alias("farming:blueberry_3", "farming:wheat_3")
minetest.register_alias("farming:blueberry_4", "farming:wheat_4")

--carrot
minetest.register_alias("farming:carrot", "farming:bread")
minetest.register_alias("farming:carrot_gold", "farming:bread")
minetest.register_alias("farming:carrot_1", "farming:wheat_1")
minetest.register_alias("farming:carrot_2", "farming:wheat_2")
minetest.register_alias("farming:carrot_3", "farming:wheat_3")
minetest.register_alias("farming:carrot_4", "farming:wheat_4")
minetest.register_alias("farming:carrot_5", "farming:wheat_5")
minetest.register_alias("farming:carrot_6", "farming:wheat_6")
minetest.register_alias("farming:carrot_7", "farming:wheat_7")
minetest.register_alias("farming:carrot_8", "farming:wheat_8")

--cocoa
minetest.register_alias("farming:cocoa_beans", "farming:bread")
minetest.register_alias("farming:cookie", "farming:bread")
minetest.register_alias("farming:chocolate_dark", "farming:flour")
minetest.register_alias("farming:cocoa_1", "default:apple")
minetest.register_alias("farming:cocoa_2", "default:apple")
minetest.register_alias("farming:cocoa_3", "default:apple")
minetest.register_alias("farming:cocoa_4", "default:apple")

--coffee
minetest.register_alias("farming:coffee_beans", "default:apple")
minetest.register_alias("farming:drinking_cup", "vessels:glass_bottle")
minetest.register_alias("farming:coffee_cup", "vessels:glass_bottle")
minetest.register_alias("farming:coffee_cup_hot", "default:apple")
minetest.register_alias("farming:coffee_1", "farming:wheat_1")
minetest.register_alias("farming:coffee_2", "farming:wheat_2")
minetest.register_alias("farming:coffee_3", "farming:wheat_3")
minetest.register_alias("farming:coffee_4", "farming:wheat_4")
minetest.register_alias("farming:coffee_5", "farming:wheat_5")

--corn
minetest.register_alias("farming:corn", "farming:bread")
minetest.register_alias("farming:corn_cob", "farming:bread")
minetest.register_alias("farming:bottle_ethanol", "vessels:glass_bottle")
minetest.register_alias("farming:corn_1", "farming:cotton_wild")
minetest.register_alias("farming:corn_2", "farming:cotton_wild")
minetest.register_alias("farming:corn_3", "farming:cotton_wild")
minetest.register_alias("farming:corn_4", "farming:cotton_wild")
minetest.register_alias("farming:corn_5", "farming:cotton_wild")
minetest.register_alias("farming:corn_6", "farming:cotton_wild")
minetest.register_alias("farming:corn_7", "farming:cotton_wild")
minetest.register_alias("farming:corn_8", "farming:cotton_wild")

--cotton  = default

--cucumber
minetest.register_alias("farming:cucumber", "farming:bread")
minetest.register_alias("farming:cucumber_1", "farming:wheat_1")
minetest.register_alias("farming:cucumber_2", "farming:wheat_2")
minetest.register_alias("farming:cucumber_3", "farming:wheat_3")
minetest.register_alias("farming:cucumber_4", "farming:cotton_wild")

--donut
minetest.register_alias("farming:donut", "farming:bread")
minetest.register_alias("farming:donut_chocolate", "farming:bread")
minetest.register_alias("farming:donut_apple", "farming:bread")

--grapes
minetest.register_alias("farming:grapes", "farming:bread")
minetest.register_alias("farming:trellis", "farming:wheat_8")
minetest.register_alias("farming:grapes_1", "farming:wheat_1")
minetest.register_alias("farming:grapes_2", "farming:wheat_2")
minetest.register_alias("farming:grapes_3", "farming:wheat_3")
minetest.register_alias("farming:grapes_4", "farming:wheat_4")
minetest.register_alias("farming:grapes_5", "farming:wheat_5")
minetest.register_alias("farming:grapes_6", "farming:wheat_6")
minetest.register_alias("farming:grapes_7", "farming:wheat_7")
minetest.register_alias("farming:grapes_8", "farming:wheat_8")
minetest.register_alias("farming:grapebush", "farming:wheat_8")

--melon
minetest.register_alias("farming:melon_slice", "farming:bread")
minetest.register_alias("farming:melon_8", "farming:wheat_8")
minetest.register_alias("farming:melon_1", "farming:wheat_1")
minetest.register_alias("farming:melon_2", "farming:wheat_2")
minetest.register_alias("farming:melon_3", "farming:wheat_3")
minetest.register_alias("farming:melon_4", "farming:wheat_4")
minetest.register_alias("farming:melon_5", "farming:wheat_5")
minetest.register_alias("farming:melon_6", "farming:wheat_6")
minetest.register_alias("farming:melon_7", "farming:wheat_7")
minetest.register_alias("farming:melon_8", "farming:wheat_8")

--potato
minetest.register_alias("farming:potato", "farming:bread")
minetest.register_alias("farming:baked_potato", "farming:bread")
minetest.register_alias("farming:potato_1", "farming:wheat_1")
minetest.register_alias("farming:potato_2", "farming:wheat_2")
minetest.register_alias("farming:potato_3", "farming:wheat_3")
minetest.register_alias("farming:potato_4", "farming:wheat_4")

--pumpkin
minetest.register_alias("farming:pumpkin", "farming:wheat_8")
minetest.register_alias("farming:pumpkin_slice", "farming:bread")
minetest.register_alias("farming:pumpkin_bread", "farming:bread")
minetest.register_alias("farming:pumpkin_dough", "farming:flour")
minetest.register_alias("farming:jackolantern", "default:meselamp")
minetest.register_alias("farming:jackolantern_on", "default:meselamp")
minetest.register_alias("farming:pumpkin_1", "farming:wheat_1")
minetest.register_alias("farming:pumpkin_2", "farming:wheat_2")
minetest.register_alias("farming:pumpkin_3", "farming:wheat_3")
minetest.register_alias("farming:pumpkin_4", "farming:wheat_4")
minetest.register_alias("farming:pumpkin_5", "farming:wheat_5")
minetest.register_alias("farming:pumpkin_6", "farming:wheat_6")
minetest.register_alias("farming:pumpkin_7", "farming:wheat_7")
minetest.register_alias("farming:pumpkin_8", "farming:wheat_8")

--raspberry
minetest.register_alias("farming:raspberries", "farming:bread")
minetest.register_alias("farming:smoothie_raspberry", "farming:bread")
minetest.register_alias("farming:raspberry_1", "farming:wheat_1")
minetest.register_alias("farming:raspberry_2", "farming:wheat_2")
minetest.register_alias("farming:raspberry_3", "farming:wheat_3")
minetest.register_alias("farming:raspberry_4", "farming:wheat_4")

--rhubarb
minetest.register_alias("farming:rhubarb", "farming:bread")
minetest.register_alias("farming:rhubarb_pie", "farming:bread")
minetest.register_alias("farming:rhubarb_1", "farming:wheat_1")
minetest.register_alias("farming:rhubarb_2", "farming:wheat_2")
minetest.register_alias("farming:rhubarb_3", "farming:wheat_3")
minetest.register_alias("farming:rhubarb_4", "farming:wheat_4")

--sugar
minetest.register_alias("farming:sugar", "farming:flour")

--tomato
minetest.register_alias("farming:tomato", "farming:bread")
minetest.register_alias("farming:tomato_1", "farming:wheat_1")
minetest.register_alias("farming:tomato_2", "farming:wheat_2")
minetest.register_alias("farming:tomato_3", "farming:wheat_3")
minetest.register_alias("farming:tomato_4", "farming:wheat_4")
minetest.register_alias("farming:tomato_5", "farming:wheat_5")
minetest.register_alias("farming:tomato_6", "farming:wheat_6")
minetest.register_alias("farming:tomato_7", "farming:wheat_7")
minetest.register_alias("farming:tomato_8", "farming:wheat_8")

