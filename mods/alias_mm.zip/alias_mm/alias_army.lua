-- mods/default/aliases_army.lua

-- MASSIVE overwrite to old nodes and items merged into default


--A R M Y--
minetest.register_alias("army:barbedwire", "default:bush_stem")
minetest.register_alias("army:camouflage", "default:leaves")
--1-15
minetest.register_alias("army:camouflage_1", "default:leaves")
minetest.register_alias("army:camouflage_2", "default:leaves")
minetest.register_alias("army:camouflage_3", "default:leaves")
minetest.register_alias("army:camouflage_4", "default:leaves")
minetest.register_alias("army:camouflage_5", "default:leaves")
minetest.register_alias("army:camouflage_6", "default:leaves")
minetest.register_alias("army:camouflage_7", "default:leaves")
minetest.register_alias("army:camouflage_8", "default:leaves")
minetest.register_alias("army:camouflage_9", "default:leaves")
minetest.register_alias("army:camouflage_10", "default:leaves")
minetest.register_alias("army:camouflage_11", "default:leaves")
minetest.register_alias("army:camouflage_12", "default:leaves")
minetest.register_alias("army:camouflage_13", "default:leaves")
minetest.register_alias("army:camouflage_14", "default:leaves")
minetest.register_alias("army:camouflage_15", "default:leaves")

--1-15
minetest.register_alias("army:chainlink", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_1", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_2", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_3", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_4", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_5", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_6", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_7", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_8", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_9", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_10", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_11", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_12", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_13", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_14", "xpanes:bar_flat")
minetest.register_alias("army:chainlink_15", "xpanes:bar_flat")



minetest.register_alias("army:light", "default:meselamp")
minetest.register_alias("army:ration", "farming:bread")
minetest.register_alias("army:sandbag", "default:sand")




