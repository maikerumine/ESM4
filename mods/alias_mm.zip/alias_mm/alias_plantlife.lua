-- mods/default/aliases_plantlife.lua

-- MASSIVE overwrite to old nodes and items merged into default


--B U S H E S--
minetest.register_alias("bushes:youngtree2_bottom", "default:fern_3")
minetest.register_alias("bushes:bushbranches1", "default:marram_grass_3")
minetest.register_alias("bushes:bushbranches2", "default:marram_grass_3")
minetest.register_alias("bushes:bushbranches3", "default:marram_grass_3")
minetest.register_alias("bushes:bushbranches4", "default:marram_grass_3")
minetest.register_alias("bushes:BushLeaves1", "default:marram_grass_3")
minetest.register_alias("bushes:BushLeaves2", "default:marram_grass_3")
minetest.register_alias("bushes:BushLeaves3", "default:marram_grass_3")
minetest.register_alias("bushes:BushLeaves4", "default:marram_grass_3")

--B U S H E S   C L A S S I C--
minetest.register_alias("bushes:blueberry", "default:grass_5")
minetest.register_alias("bushes:blackberry", "default:marram_grass_3")
minetest.register_alias("bushes:raspberry", "default:marram_grass_3")
minetest.register_alias("bushes:strawberry", "default:marram_grass_3")
minetest.register_alias("bushes:gooseberry", "default:marram_grass_3")
minetest.register_alias("bushes:mixed_berry", "default:marram_grass_3")

minetest.register_alias("bushes:fruitless_bush", "default:bush_stem")
minetest.register_alias("bushes:blueberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:blackberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:raspberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:strawberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:gooseberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:mixed_berry_bush", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes:basket_blueberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:basket_blackberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:basket_raspberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:basket_strawberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:basket_gooseberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:basket_mixed_berry", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes:blueberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:blackberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:raspberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:strawberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:gooseberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:mixed_berry_pie_raw", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes:blueberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:blackberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:raspberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:strawberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:gooseberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:mixed_berry_pie_cooked", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes:blueberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:blackberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:raspberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:strawberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:gooseberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes:mixed_berry_pie_slice", "default:blueberry_bush_leaves_with_berries")

--classic
minetest.register_alias("bushes_classic:blueberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:blackberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:raspberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:strawberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:gooseberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:mixed_berry", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes_classic:fruitless_bush", "default:bush_stem")
minetest.register_alias("bushes_classic:blueberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:blackberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:raspberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:strawberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:gooseberry_bush", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:mixed_berry_bush", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes_classic:basket_blueberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:basket_blackberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:basket_raspberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:basket_strawberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:basket_gooseberry", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:basket_mixed_berry", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes_classic:blueberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:blackberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:raspberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:strawberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:gooseberry_pie_raw", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:mixed_berry_pie_raw", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes_classic:blueberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:blackberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:raspberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:strawberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:gooseberry_pie_cooked", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:mixed_berry_pie_cooked", "default:blueberry_bush_leaves_with_berries")

minetest.register_alias("bushes_classic:blueberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:blackberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:raspberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:strawberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:gooseberry_pie_slice", "default:blueberry_bush_leaves_with_berries")
minetest.register_alias("bushes_classic:mixed_berry_pie_slice", "default:blueberry_bush_leaves_with_berries")

--D R Y P L A N T S--
minetest.register_alias("dryplants:sickle", "default:bush_stem")
minetest.register_alias("dryplants:grass", "default:bush_stem")
minetest.register_alias("dryplants:hay", "default:bush_stem")
minetest.register_alias("dryplants:grass_short", "default:bush_stem")
minetest.register_alias("dryplants:wetreed", "default:bush_stem")
minetest.register_alias("dryplants:reed", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_water", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_water_entity", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_sapling", "default:bush_stem")
minetest.register_alias("dryplants:reedmace", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_height_2", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_height_3", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_height_3_spikes", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_spikes", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_top", "default:bush_stem")
minetest.register_alias("dryplants:reedmace_bottom", "default:bush_stem")

minetest.register_alias("dryplants:wetreed_slab", "default:bush_stem")
minetest.register_alias("dryplants:reed_slab", "default:bush_stem")
minetest.register_alias("dryplants:wetreed_roof", "default:bush_stem")
minetest.register_alias("dryplants:reed_roof", "default:bush_stem")
minetest.register_alias("dryplants:wetreed_roof_corner", "default:bush_stem")
minetest.register_alias("dryplants:reed_roof_corner", "default:bush_stem")

minetest.register_alias("dryplants:dandelion_leave", "default:bush_stem")
minetest.register_alias("dryplants:juncus", "default:bush_stem")
minetest.register_alias("dryplants:juncus_02", "default:bush_stem")

minetest.register_alias("dryplants:reedmace_water_entity", "default:junglegrass")




--F E R N S--
minetest.register_alias("ferns:horsetail_01", "default:junglegrass")
minetest.register_alias("ferns:horsetail_02", "default:junglegrass")
minetest.register_alias("ferns:horsetail_03", "default:junglegrass")
minetest.register_alias("ferns:horsetail_04", "default:junglegrass")
minetest.register_alias("ferns:fern_01", "default:junglegrass")
minetest.register_alias("ferns:fern_02", "default:junglegrass")
minetest.register_alias("ferns:fern_03", "default:junglegrass")
minetest.register_alias("ferns:tree_fern_leaves", "default:junglegrass")
minetest.register_alias("ferns:tree_fern_leaves_02", "default:junglegrass")
minetest.register_alias("ferns:fern_trunk", "default:junglegrass")
minetest.register_alias("ferns:sapling_tree_fern", "default:junglegrass")

minetest.register_alias("ferns:fiddlehead", "default:junglegrass")
minetest.register_alias("ferns:fiddlehead_roasted", "default:junglegrass")
minetest.register_alias("ferns:ferntuber", "default:junglegrass")
minetest.register_alias("ferns:ferntuber_roasted", "default:junglegrass")

minetest.register_alias("ferns:fern_trunk_big", "default:junglegrass")
minetest.register_alias("ferns:fern_trunk_big_top", "default:junglegrass")
minetest.register_alias("ferns:tree_fern_leaves_giant", "default:junglegrass")
minetest.register_alias("ferns:tree_fern_leave_big", "default:junglegrass")
minetest.register_alias("ferns:tree_fern_leave_big_end", "default:junglegrass")
minetest.register_alias("ferns:sapling_giant_tree_fern", "default:junglegrass")

--F L O W E R S--


--M O L E H I L L S--
minetest.register_alias("molehills:molehill", "air")

--N A T U R E   C L A S S I C--
minetest.register_alias("nature:blossom", "default:leaves")

--P O I S O N I V Y--
minetest.register_alias("poisonivy:seedling", "air")
minetest.register_alias("poisonivy:sproutling", "air")
minetest.register_alias("poisonivy:climbing", "air")

--T R U N K S--
minetest.register_alias("trunks:twig_1", "air")
minetest.register_alias("trunks:twig_2", "air")
minetest.register_alias("trunks:twig_3", "air")
minetest.register_alias("trunks:twig_4", "air")
minetest.register_alias("trunks:twig_5", "air")
minetest.register_alias("trunks:twig_6", "air")
minetest.register_alias("trunks:twig_7", "air")
minetest.register_alias("trunks:twig_8", "air")
minetest.register_alias("trunks:twig_9", "air")
minetest.register_alias("trunks:twig_10", "air")
minetest.register_alias("trunks:twig_11", "air")
minetest.register_alias("trunks:twig_12", "air")
minetest.register_alias("trunks:twig_13", "air")
minetest.register_alias("trunks:twig_14", "air")
minetest.register_alias("trunks:twig_15", "air")
minetest.register_alias("trunks:twig_16", "air")
minetest.register_alias("trunks:twig_17", "air")
minetest.register_alias("trunks:twig_18", "air")
minetest.register_alias("trunks:twig_19", "air")
minetest.register_alias("trunks:twigs", "air")
minetest.register_alias("trunks:treeroot", "air")

minetest.register_alias("trunks:twigs_slab", "air")
minetest.register_alias("trunks:twigs_roof", "air")
minetest.register_alias("trunks:twigs_roof_corner", "air")
minetest.register_alias("trunks:twigs_roof_corner_2", "air")
minetest.register_alias("trunks:twigs_roof_corner_2", "air")

minetest.register_alias("trunks:moss", "air")
minetest.register_alias("trunks:moss_fungus", "air")

--V I N E S--
minetest.register_alias("vines:rope_block", "air")
minetest.register_alias("vines:vine", "air")
minetest.register_alias("vines:vine_middle", "air")
minetest.register_alias("vines:vine_end", "air")
minetest.register_alias("vines:vine_rotten", "air")
minetest.register_alias("vines:rope", "air")
minetest.register_alias("vines:rope_end", "air")
minetest.register_alias("vines:shears", "default:dirt")

minetest.register_alias("vines:root", "air")
minetest.register_alias("vines:root_middle", "air")
minetest.register_alias("vines:root_end", "air")

minetest.register_alias("vines:jungle", "air")
minetest.register_alias("vines:jungle_middle", "air")
minetest.register_alias("vines:jungle_end", "air")

minetest.register_alias("vines:side", "air")
minetest.register_alias("vines:side_middle", "air")
minetest.register_alias("vines:side_end", "air")

minetest.register_alias("vines:willow", "air")
minetest.register_alias("vines:willow_middle", "air")
minetest.register_alias("vines:willow_end", "air")


--W O O D S O I L S--
minetest.register_alias("woodsoils:grass_with_leaves_1", "default:dirt")
minetest.register_alias("woodsoils:grass_with_leaves_2", "default:dirt")
minetest.register_alias("woodsoils:dirt_with_leaves_1", "default:dirt")
minetest.register_alias("woodsoils:dirt_with_leaves_2", "default:dirt")

--Y O U N G T R E E S--
minetest.register_alias("youngtrees:bamboo", "air")
minetest.register_alias("youngtrees:youngtree2_middle", "air")
minetest.register_alias("youngtrees:youngtree_top", "air")
minetest.register_alias("youngtrees:youngtree_middle", "air")
minetest.register_alias("youngtrees:youngtree_bottom", "air")
minetest.register_alias("youngtrees:youngtree_bottom", "air")















