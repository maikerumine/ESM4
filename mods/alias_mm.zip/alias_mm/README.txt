Minetest Game mod: alais_mm
========================
See license.txt for license information.

Authors of source code
----------------------
Originally by maikerumine (MIT)



