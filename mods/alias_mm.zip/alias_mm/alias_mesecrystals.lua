-- mods/default/aliases_mesecrystals.lua

-- MASSIVE overwrite to old nodes and items merged into default


--M E S E   C R Y S T A L S--
minetest.register_alias("mese_crystals:mese_crystal_ore1", "default:stone_with_mese")
minetest.register_alias("mese_crystals:mese_crystal_ore2", "default:stone_with_mese")
minetest.register_alias("mese_crystals:mese_crystal_ore3", "default:stone_with_mese")
minetest.register_alias("mese_crystals:mese_crystal_ore4", "default:stone_with_mese")
minetest.register_alias("mese_crystals:crystaline_bell", "default:pick_mese")
minetest.register_alias("mese_crystals:mese_crystal_seed", "default:stone_with_mese")





