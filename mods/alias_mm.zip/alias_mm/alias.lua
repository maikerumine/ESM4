--Extreme Survival created by maikerumine
-- Minetest 0.4.16 mod: "Extreme Survival"
-- namespace: es
--version 0.4.16
--https://github.com/maikerumine

--License:
--~~~~~~~~
--Code:
--(c) Copyright 2015-2020 maikerumine; modified zlib-License
--see "LICENSE.txt" for details.

--Media(if not stated differently):
--(c) Copyright (2014-2020) maikerumine; CC-BY-SA 3.0

--Alias                      "old"--->"new"
------------------------------------------


--===========================================
--===========================================
--This is to fix the old interaction with my modified 3d_armor mod.
--NEED TO USE THIS FOR 3-D ARMOUR TO WORK!!!!!
minetest.register_alias("es:helmet_aikerum", "3d_armor:helmet_aikerum")
minetest.register_alias("es:helmet_emerald", "3d_armor:helmet_emerald")
minetest.register_alias("es:helmet_infinium", "3d_armor:helmet_infinium")
minetest.register_alias("es:chestplate_aikerum", "3d_armor:chestplate_aikerum")
minetest.register_alias("es:chestplate_emerald", "3d_armor:chestplate_emerald")
minetest.register_alias("es:chestplate_infinium", "3d_armor:chestplate_infinium")
minetest.register_alias("es:leggings_aikerum", "3d_armor:leggings_aikerum")
minetest.register_alias("es:leggings_emerald", "3d_armor:leggings_emerald")
minetest.register_alias("es:leggings_infinium", "3d_armor:leggings_infinium")
minetest.register_alias("es:boots_aikerum", "3d_armor:boots_aikerum")
minetest.register_alias("es:boots_emerald", "3d_armor:boots_emerald")
minetest.register_alias("es:boots_infinium", "3d_armor:boots_infinium")

minetest.register_alias("es:shield_aikerum", "shields:shield_aikerum")
minetest.register_alias("es:shield_emerald", "shields:shield_emerald")
minetest.register_alias("es:shield_infinium", "shields:shield_infinium")
minetest.register_alias("es:shield_nomad", "shields:shield_nomad")
minetest.register_alias("es:shield_rusher", "shields:shield_rusher")
minetest.register_alias("es:shield_veteran", "shields:shield_veteran")


--===========================================
--===========================================
--bags
minetest.register_alias("bags:small_esmmese", "unified_inventory:small_esmmese")
minetest.register_alias("bags:medium_esmmese", "unified_inventory:medium_esmmese")
minetest.register_alias("bags:large_esmmese", "unified_inventory:large_esmmese")
minetest.register_alias("bags:small", "unified_inventory:small_esmmese")
minetest.register_alias("bags:medium", "unified_inventory:medium_esmmese")
minetest.register_alias("bags:large", "unified_inventory:large_esmmese")
minetest.register_alias("bags:small_mese", "unified_inventory:small_esmmese")
minetest.register_alias("bags:medium_mese", "unified_inventory:medium_esmmese")
minetest.register_alias("bags:large_mese", "unified_inventory:large_esmmese")


--===========================================
--===========================================
--beds
minetest.register_alias("beds:bed_bottom_white", "beds:bed_bottom")
minetest.register_alias("beds:bed_top_white", "beds:bed_top")



--===========================================
--===========================================
--binoculars
minetest.register_alias("binoculars:binoculars", "default:diamondblock")

--===========================================
--===========================================
--binoculars
minetest.register_alias("bedrock2:bedrock", "default:coalblock")

--===========================================
--===========================================
--bags
minetest.register_alias("bags:small_esmmese", "default:chest")
minetest.register_alias("bags:medium_esmmese", "default:chest")
minetest.register_alias("bags:large_esmmese", "default:chest")

minetest.register_alias("unified_inventory:small_esmmese", "default:chest")
minetest.register_alias("unified_inventory:medium_esmmese", "default:chest")
minetest.register_alias("unified_inventory:large_esmmese", "default:chest")


minetest.register_alias("bags:lsmall_mese", "default:chest")
minetest.register_alias("bags:lmedium_mese", "default:chest")
minetest.register_alias("bags:llarge_mese", "default:chest")
--===========================================
--===========================================
--carts
minetest.register_alias("carts:rail_brake","carts:brakerail")
minetest.register_alias("carts:rail_power","carts:powerrail")


--===========================================
--===========================================
--override default nodes
minetest.register_alias("default:desert_stone_with_iron", "es:desert_stone_with_iron")
minetest.register_alias("default:desert_stone_with_gold", "es:desert_stone_with_gold")
minetest.register_alias("default:desert_stone_with_coal", "es:desert_stone_with_coal")

minetest.register_alias("default:copper_block", "default:copperblock")
minetest.register_alias("default:steel_block_block", "default:steelblock")



--===========================================
--===========================================
--doors
--[[
minetest.register_alias("doors:door_wood_t_1", "default:wood")
minetest.register_alias("doors:door_wood_b_1", "default:wood")
minetest.register_alias("doors:door_wood_b_2", "default:wood")
minetest.register_alias("doors:door_wood_t_2", "default:wood")
]]

minetest.register_alias("doors:door_wood_t_1", "doors:hidden")
minetest.register_alias("doors:door_wood_b_1", "doors:door_wood_a")
minetest.register_alias("doors:door_wood_b_2", "doors:door_wood_b")
minetest.register_alias("doors:door_wood_t_2", "doors:hidden")

minetest.register_alias("doors:door_steel_t_1", "doors:hidden")
minetest.register_alias("doors:door_steel_b_1", "doors:door_steel_a")
minetest.register_alias("doors:door_steel_b_2", "doors:door_steel_b")
minetest.register_alias("doors:door_steel_t_2", "doors:hidden")


--===========================================
--===========================================
--es crushing furnace
minetest.register_alias("es:furnace", "es:infiniumblock")
minetest.register_alias("es:furnace_active", "es:infiniumblock")
minetest.register_alias("es:cfurnace", "es:infiniumblock")
minetest.register_alias("es:cfurnace_active", "es:infiniumblock")

--===========================================
--===========================================
--es nodes

--es:muddy_block
minetest.register_alias("es:mud", "default:stone")
minetest.register_alias("es:punkin_slice", "default:stone")

minetest.register_alias("es:strange_clay", "es:strange_clay_blue")
minetest.register_alias("es:stone_with_mese", "default:stone_with_mese")
minetest.register_alias("es:stone_with_coal", "default:stone_with_coal")
minetest.register_alias("es:stone_with_emerald", "default:stone_with_iron")
minetest.register_alias("es:stone_with_ruby", "default:stone_with_copper")
minetest.register_alias("es:stone_with_aikerum", "default:stone_with_diamond")
minetest.register_alias("es:stone_with_infinium", "default:stone_with_mese")
minetest.register_alias("es:stone_with_purpellium", "default:stone_with_coal")
minetest.register_alias("es:depleted_uranium", "default:stone_with_gold")




--===========================================
--===========================================
--fishing
minetest.register_alias("fishing:pole", "fishing:pole_wood")
minetest.register_alias("fishing:bait_corn", "farming:bread")
minetest.register_alias("fishing:sushi", "farming:bread")
minetest.register_alias("fishing:baitball", "farming:bread")
minetest.register_alias("fishing:baitball_shark", "farming:bread")
minetest.register_alias("fishing:bait_worm", "farming:bread")


--===========================================
--===========================================
--jukebox
minetest.register_alias("jdukebox:box", "default:diamondblock")


--===========================================
--===========================================
--lavender
minetest.register_alias("lavender:lavender_fruit", "flowers:rose")
minetest.register_alias("lavender:lavender", "flowers:viola")


--===========================================
--===========================================

--legacy
minetest.register_alias(":firefly", "fireflies:firefly_bottle")
minetest.register_alias("firefly", "fireflies:firefly_bottle")
minetest.register_alias("default:firefly", "fireflies:firefly_bottle")
minetest.register_alias("legacy:firefly", "fireflies:firefly_bottle")
--[[
--legacy
minetest.register_craft({
	type = "shapeless",
	output = "fireflies:firefly",
	recipe = {":firefly"},
})
]]
minetest.register_alias("default:scorched_stuff", "default:dry_shrub")



--===========================================
--===========================================
--map
minetest.register_alias("map:mapping_kit", "default:diamondblock")


--===========================================
--===========================================
--meru
minetest.register_alias("meru:destone", "default:desert_stone")
minetest.register_alias("meru:stone", "default:sandstone")


--===========================================
--===========================================
--moreores
minetest.register_alias("moreores:mineral_mithril", "default:stone_with_tin")
minetest.register_alias("moreores:mineral_silver", "default:stone_with_tin")
minetest.register_alias("moreores:mineral_tin", "default:stone_with_tin")
minetest.register_alias("moreores:mithril_block", "es:aikerumblock")
minetest.register_alias("moreores:silver_block", "es:rubyblock")
minetest.register_alias("moreores:tin_block", "default:steelblock")

minetest.register_alias("moreores:mithril_ingot", "es:infinium_goo")
minetest.register_alias("moreores:silver_ingot", "es:aikerum_crystal")
minetest.register_alias("moreores:tin_ingot", "es:ruby_crystal")

minetest.register_alias("moreores:mithril_lump", "default:mese")
minetest.register_alias("moreores:silver_lump", "default:gold_lump")
minetest.register_alias("moreores:tin_lump", "default:iron_lump")

minetest.register_alias("moreores:sword_mithril", "es:sword_aikerum")
minetest.register_alias("moreores:pick_mithril", "es:pick_aikerum")
minetest.register_alias("moreores:shovel_mithril", "es:shovel_aikerum")
minetest.register_alias("moreores:hoe_mithril", "farming:hoe_diamond")
minetest.register_alias("moreores:axe_mithril", "es:axe_aikerum")

minetest.register_alias("moreores:sword_silver", "es:sword_ruby")
minetest.register_alias("moreores:pick_silver", "es:pick_ruby")
minetest.register_alias("moreores:shovel_silver", "es:shovel_ruby")
minetest.register_alias("moreores:hoe_silver", "farming:hoe_diamond")
minetest.register_alias("moreores:axe_silver", "es:axe_ruby")

minetest.register_alias("3d_armor:helmet_mithril", "es:helmet_aikerum")
minetest.register_alias("3d_armor:chestplate_mithril", "es:chestplate_aikerum")
minetest.register_alias("3d_armor:leggings_mithril", "es:leggings_aikerum")
minetest.register_alias("3d_armor:boots_mithril", "es:boots_aikerum")


--===========================================
--===========================================
--moresnow
minetest.register_alias("moresnow:snow_top", "default:snow")
minetest.register_alias("moresnow:snow_fence_top", "default:snow")
minetest.register_alias("moresnow:snow_stair_top", "default:snow")
minetest.register_alias("moresnow:snow_slab_top", "default:snow")
minetest.register_alias("moresnow:snow_panel_top", "default:snow")
minetest.register_alias("moresnow:snow_micro_top", "default:snow")
minetest.register_alias("moresnow:snow_outer_stair_top", "default:snow")
minetest.register_alias("moresnow:snow_inner_stair_top", "default:snow")
minetest.register_alias("moresnow:snow_ramp_top", "default:snow")
minetest.register_alias("moresnow:snow_ramp_outer_top", "default:snow")
minetest.register_alias("moresnow:snow_ramp_inner_top", "default:snow")
--wool
minetest.register_alias("moresnow:wool_white", "stairs:slab1_wool_white")
minetest.register_alias("moresnow:wool_grey", "stairs:slab1_wool_grey")
minetest.register_alias("moresnow:wool_black", "stairs:slab1_wool_black")
minetest.register_alias("moresnow:wool_red", "stairs:slab1_wool_red")
minetest.register_alias("moresnow:wool_yellow", "stairs:slab1_wool_yellow")
minetest.register_alias("moresnow:wool_green", "stairs:slab1_wool_green")
minetest.register_alias("moresnow:wool_cyan", "stairs:slab1_wool_cyan")
minetest.register_alias("moresnow:wool_blue", "stairs:slab1_wool_blue")
minetest.register_alias("moresnow:wool_magenta", "stairs:slab1_wool_magenta")
minetest.register_alias("moresnow:wool_orange", "stairs:slab1_wool_orange")
minetest.register_alias("moresnow:wool_violet", "stairs:slab1_wool_violet")
minetest.register_alias("moresnow:wool_brown", "stairs:slab1_wool_brown")
minetest.register_alias("moresnow:wool_pink", "stairs:slab1_wool_pink")
minetest.register_alias("moresnow:wool_dark_grey", "stairs:slab1_wool_dark_grey")
minetest.register_alias("moresnow:wool_dark_green", "stairs:slab1_wool_dark_green")
minetest.register_alias("moresnow:wool_white_top", "stairs:slab1_wool_white")
minetest.register_alias("moresnow:wool_grey_top", "stairs:slab1_wool_grey")
minetest.register_alias("moresnow:wool_black_top", "stairs:slab1_wool_black")
minetest.register_alias("moresnow:wool_red_top", "stairs:slab1_wool_red")
minetest.register_alias("moresnow:wool_yellow_top", "stairs:slab1_wool_yellow")
minetest.register_alias("moresnow:wool_green_top", "stairs:slab1_wool_green")
minetest.register_alias("moresnow:wool_cyan_top", "stairs:slab1_wool_cyan")
minetest.register_alias("moresnow:wool_blue_top", "stairs:slab1_wool_blue")
minetest.register_alias("moresnow:wool_magenta_top", "stairs:slab1_wool_magenta")
minetest.register_alias("moresnow:wool_orange_top", "stairs:slab1_wool_orange")
minetest.register_alias("moresnow:wool_violet_top", "stairs:slab1_wool_violet")
minetest.register_alias("moresnow:wool_brown_top", "stairs:slab1_wool_brown")
minetest.register_alias("moresnow:wool_pink_top", "stairs:slab1_wool_pink")
minetest.register_alias("moresnow:wool_dark_grey_top", "stairs:slab1_wool_dark_grey")
minetest.register_alias("moresnow:wool_dark_green_top", "stairs:slab1_wool_dark_green")
--leaves
minetest.register_alias("moresnow:autumnleaves", "default:leaves")
minetest.register_alias("moresnow:autumnleaves_tree", "default:leaves")
minetest.register_alias("moresnow:winterleaves_tree", "default:leaves")
minetest.register_alias("moresnow:snow_soil", "default:dirt_with_snow")





--===========================================
--===========================================
--pathv6alt
minetest.register_alias("pathv6alt:path", "default:stonebrick")
minetest.register_alias("pathv6alt:junglewood", "default:stonebrick")
minetest.register_alias("pathv6alt:bridgewood", "default:junglewood")
minetest.register_alias("pathv6alt:stairn", "default:junglewood")
minetest.register_alias("pathv6alt:stairs", "default:junglewood")
minetest.register_alias("pathv6alt:staire", "default:junglewood")
minetest.register_alias("pathv6alt:stairw", "default:junglewood")
minetest.register_alias("pathv6alt:stairne", "default:junglewood")
minetest.register_alias("pathv6alt:stairse", "default:junglewood")
minetest.register_alias("pathv6alt:stairsw", "default:junglewood")
minetest.register_alias("pathv6alt:stairnw", "default:junglewood")
minetest.register_alias("pathv6alt:pstairn", "default:junglewood")
minetest.register_alias("pathv6alt:pstairs", "default:junglewood")
minetest.register_alias("pathv6alt:pstaire", "default:junglewood")
minetest.register_alias("pathv6alt:pstairw", "default:junglewood")
minetest.register_alias("pathv6alt:pstairne", "default:junglewood")
minetest.register_alias("pathv6alt:pstairse", "default:junglewood")
minetest.register_alias("pathv6alt:pstairsw", "default:junglewood")
minetest.register_alias("pathv6alt:pstairnw", "default:junglewood")


--===========================================
--===========================================
--protector
minetest.register_alias("protector_mese:protect", "protector:protect")
minetest.register_alias("protector_mese:display", "protector:display")
minetest.register_alias("protector_mese:stick", "default:stick")
minetest.register_alias("protector:chest", "default:chest_locked")
minetest.register_alias("protector:trapdoor", "doors:trapdoor")
minetest.register_alias("protector:trapdoor_open", "doors:trapdoor")
minetest.register_alias("protector:trapdoor_steel", "doors:trapdoor")
minetest.register_alias("protector:trapdoor_steel_open", "doors:trapdoor")


minetest.register_alias("protector:door_steel", "doors:door_steel")
minetest.register_alias("protector:door_wood", "doors:door_wood")

minetest.register_alias("protector:door_wood_t_1", "doors:hidden")
minetest.register_alias("protector:door_wood_b_1", "doors:door_wood_a")
minetest.register_alias("protector:door_wood_b_2", "doors:door_wood_b")
minetest.register_alias("protector:door_wood_t_2", "doors:hidden")

minetest.register_alias("protector:door_steel_t_1", "doors:hidden")
minetest.register_alias("protector:door_steel_b_1", "doors:door_steel_a")
minetest.register_alias("protector:door_steel_b_2", "doors:door_steel_b")
minetest.register_alias("protector:door_steel_t_2", "doors:hidden")



--===========================================
--===========================================
--screwdriver
minetest.register_alias("screwdriver:screwdriver","slap_rotate:glove")
minetest.register_alias("slab_rotate:glove","slap_rotate:glove")


--===========================================
--===========================================
--travelnet
minetest.register_alias("travelnet:elevator", "default:diamondblock")
minetest.register_alias("travelnet:elevator_door_glass_open", "default:bronzeblock")
minetest.register_alias("travelnet:elevator_door_glass_closed", "default:bronzeblock")
minetest.register_alias("travelnet:elevator_door_stone_open", "default:bronzeblock")
minetest.register_alias("travelnet:elevator_door_stone_closed", "default:bronzeblock")
minetest.register_alias("travelnet:elevator_door_steel_open", "default:bronzeblock")
minetest.register_alias("travelnet:elevator_door_steel_closed", "default:bronzeblock")


--===========================================
--===========================================
--vendor
--[[
minetest.register_alias("vendor:vendor", "smartshop:shop")
minetest.register_alias("vendor:depositor", "smartshop:shop")
minetest.register_alias("vendorgoldblock:vendor", "smartshop:shop")
minetest.register_alias("vendorgoldblock:depositor", "smartshop:shop")

minetest.register_alias("vendor:vendor", "vendor:vendor")
minetest.register_alias("vendor:depositor", "vendor:depositor")
minetest.register_alias("vendorgoldblock:vendor", "vendor:vendor")
minetest.register_alias("vendorgoldblock:depositor", "vendor:depositor")
]]
minetest.register_alias("smartshop:shop", "vendor:vendor")
minetest.register_alias("smartshop:item", "default:ladder")
--===========================================
--===========================================
--villages
minetest.register_alias("mg_villages:torch", "default:torch")
minetest.register_alias("handle_schematics:support", "default:ladder")
minetest.register_alias("mg_villages:road", "default:gravel")
minetest.register_alias("mg_villages:soil", "default:dirt")
minetest.register_alias("mg_villages:desert_sand_soil", "default:desert_sand")
minetest.register_alias("mg_villages:plotmarker", "stairs:slab_stonebrick")
minetest.register_alias("mg_villages:lava_flowing_tamed", "default:lava_flowing")
minetest.register_alias("mg_villages:lava_source_tamed", "default:lava_source")


--===========================================
--===========================================
--misc
minetest.register_alias("3d_armor_stand:armor_stand", "default:ladder")
minetest.register_alias("3d_armor_stand:locked_armor_stand", "default:mese")
minetest.register_alias("3d_armor_stand:armor_entity", "default:mese")

minetest.register_alias("itemframes:frame", "default:wood")
minetest.register_alias("itemframes:pedestal", "default:wood")
minetest.register_alias("itemframes:item", "mobs:Sam")--entity




--minetest.register_alias("inbox:empty", "xdecor:mailbox")

--kick voting and misc justtest nodes
minetest.register_alias("kick_voting:table", "default:mese")
minetest.register_alias("wield3d:wield_entity", "mobs:Sam")
minetest.register_alias("fire_extinguisher:extinguisher", "default:goldblock")
minetest.register_alias("gold_mark:mark", "default:goldblock")
minetest.register_alias("diamond_mark:mark", "default:diamondblock")


--===========================================
--===========================================
--shooter
minetest.register_alias("shooter:pistol", "mobs:blue_laser_gun")
minetest.register_alias("shooter:rifle", "mobs:blue_laser_gun")
minetest.register_alias("shooter:machine_gun", "mobs:red_laser_gun")
minetest.register_alias("shooter:ammo", "mobs:laser")
--{"white", "grey", "black", "red", "yellow", "green", "cyan", "blue", "magenta"}


minetest.register_alias("shooter:crossbow", "mobs:blue_laser_gun")
minetest.register_alias("shooter:arrow_white", "mobs:blue_laser_gun")
minetest.register_alias("shooter:flaregun", "mobs:blue_laser_gun")
minetest.register_alias("shooter:flare", "mobs:laser")
minetest.register_alias("shooter:flare_light", "mobs:cobweb")

minetest.register_alias("shooter:grapple_hook", "mobs:cobweb")
minetest.register_alias("shooter:grapple_gun", "mobs:blue_laser_gun")
minetest.register_alias("shooter:grapple_gun_loaded", "mobs:blue_laser_gun")

minetest.register_alias("shooter:grenade", "mobs:blue_laser_gun")
minetest.register_alias("shooter:rocket", "mobs:blue_laser_gun")
minetest.register_alias("shooter:rocket_gun", "mobs:blue_laser_gun")
minetest.register_alias("shooter:rocket_gun_loaded", "mobs:blue_laser_gun")
--throwing
minetest.register_alias("throwing:blue_laser_gun", "mobs:blue_laser_gun")
minetest.register_alias("throwing:red_laser_gun", "mobs:red_laser_gun")
minetest.register_alias("throwing:laser", "mobs:laser")



--tsmines
minetest.register_alias("tsm_mines:dummy", "default:torch")


--===========================================
--===========================================
--walls
minetest.register_alias("walls:emerald", "walls:emeraldblock")
minetest.register_alias("walls:ruby", "walls:rubyblock")
minetest.register_alias("walls:aikerum", "walls:aikerumblock")
minetest.register_alias("walls:purpellium", "walls:purpelliumblock")
minetest.register_alias("walls:infinium", "walls:infiniumblock")


--===========================================
--===========================================
--villages
minetest.register_alias("mg_villages:torch", "default:torch")
minetest.register_alias("handle_schematics:support", "default:ladder")
minetest.register_alias("mg_villages:road", "default:gravel")
minetest.register_alias("mg_villages:soil", "default:dirt")
minetest.register_alias("mg_villages:desert_sand_soil", "default:desert_sand")
minetest.register_alias("mg_villages:plotmarker", "stairs:slab_stonebrick")
minetest.register_alias("mg_villages:lava_flowing_tamed", "default:lava_flowing")
minetest.register_alias("mg_villages:lava_source_tamed", "default:lava_source")


