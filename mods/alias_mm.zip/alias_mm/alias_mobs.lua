-- mods/default/aliases_mesecrystals.lua

-- MASSIVE overwrite to old nodes and items merged into default


--M O B S --
--===========================================
--===========================================
--badplayer
minetest.register_alias("badplayer:meat_raw", "mobs:meat_raw")
minetest.register_alias("badplayer:meat", "mobs:meat")



--creatures
minetest.register_alias("creatures:rotten_flesh", "mobs:leather")


--esmobs 
minetest.register_alias("esmobs:nametag", "mobs:nametag")
minetest.register_alias("esmobs:leather", "mobs:leather")
minetest.register_alias("esmobs:rotten_flesh", "mobs:leather")
minetest.register_alias("esmobs:meat_raw", "mobs:meat_raw")
minetest.register_alias("esmobs:beef_raw", "mobs:meat_raw")
minetest.register_alias("esmobs:mutton_raw", "mobs:meat_raw")
minetest.register_alias("esmobs:meat", "mobs:meat")
minetest.register_alias("esmobs:beef", "mobs:meat")
minetest.register_alias("esmobs:mutton", "mobs:meat")
minetest.register_alias("esmobs:pork_raw", "mobs:pork_raw")
minetest.register_alias("esmobs:porkchop_raw", "mobs:pork_raw")
minetest.register_alias("esmobs:pork_cooked", "mobs:pork_cooked")
minetest.register_alias("esmobs:porkchop_cooked", "mobs:pork_cooked")
minetest.register_alias("esmobs:rat_cooked", "mobs:rat_cooked")
minetest.register_alias("esmobs:rat", "mobs:rat")
minetest.register_alias("esmobs:egg_entity", "mobs:egg_entity")
minetest.register_alias("esmobs:egg", "mobs:egg")
minetest.register_alias("esmobs:chicken_egg_fried", "mobs:chicken_egg_fried")
minetest.register_alias("esmobs:chicken_raw", "mobs:chicken_raw")
minetest.register_alias("esmobs:chicken_cooked", "mobs:chicken_cooked")
minetest.register_alias("esmobs:magic_lasso", "mobs:magic_lasso")
minetest.register_alias("esmobs:net", "mobs:net")
minetest.register_alias("esmobs:shears", "mobs:shears")
minetest.register_alias("esmobs:feather", "mobs:feather")
minetest.register_alias("esmobs:saddle", "mobs:saddle")
minetest.register_alias("esmobs:bucket_milk", "mobs:bucket_milk")
minetest.register_alias("esmobs:cheese", "mobs:cheese")
minetest.register_alias("esmobs:cheeseblock", "mobs:cheeseblock")
minetest.register_alias("esmobs:cobweb", "mobs:cobweb")
minetest.register_alias("esmobs:spawner", "mobs:spawner")
minetest.register_alias("esmobs:bones", "mobs:bones")
minetest.register_alias("esmobs:fireball", "mobs:fireball")
minetest.register_alias("esmobs:arrow", "mobs:arrow")
minetest.register_alias("esmobs:arrow_diamond", "mobs:arrow_diamond")
minetest.register_alias("esmobs:arrow_box", "mobs:arrow_box")
minetest.register_alias("esmobs:arrow_diamond_box", "mobs:arrow_diamond_box")
minetest.register_alias("esmobs:arrow_entity", "mobs:arrow_entity")
minetest.register_alias("esmobs:bow_wood", "mobs:bow_wood")
minetest.register_alias("esmobs:arrow_diamond_entity", "mobs:arrow_diamond_entity")
minetest.register_alias("esmobs:arrow_diamond_entity", "mobs:arrow_diamond_entity")
minetest.register_alias("esmobs:bonebullet", "mobs:bonebullet")
minetest.register_alias("esmobs:bookbullet", "mobs:bookbullet")
minetest.register_alias("esmobs:axebullet", "mobs:axebullet")
minetest.register_alias("esmobs:cursed_stone", "default:goldblock")
minetest.register_alias("esmobs:blessed_stone", "default:goldblock")
minetest.register_alias("esmobs:stone", "default:leaves")
minetest.register_alias("esmobs:dirt", "default:leaves")

--===========================================
--===========================================
--mobs

--redo
minetest.register_alias("mobs:magic_lasso", "default:shovel_steel")
minetest.register_alias("mobs:net", "default:shovel_steel")
minetest.register_alias("mobs:shears", "default:sword_steel")
minetest.register_alias("mobs:cobweb", "default:glass")
minetest.register_alias("mobs:nametag", "default:paper")
minetest.register_alias("mobs:leather", "default:paper")
minetest.register_alias("mobs:saddle", "default:paper")
minetest.register_alias("mobs:arrow", "mobs:laser")
minetest.register_alias("mobs:bow_wood", "mobs:blue_laser_gun")

--bee
minetest.register_alias("mobs:honey", "mobs:rat_cooked")
minetest.register_alias("mobs:beehive", "default:goldblock")
minetest.register_alias("mobs:honey_block", "default:goldblock")
--chicken
minetest.register_alias("mobs:egg", "default:glass")
minetest.register_alias("mobs_animal:chicken", "default:glass")
minetest.register_alias("mobs:feather", "default:paper")
minetest.register_alias("mobs:chicken_egg_fried", "mobs:rat_cooked")
minetest.register_alias("mobsl:chicken_egg_fried", "mobs:rat_cooked")
minetest.register_alias("mobs:chicken_raw", "mobs:rat")
minetest.register_alias("mobs:chicken_cooked", "mobs:rat_cooked")
--cow
minetest.register_alias("mobs:bucket_milk", "mobs:rat_cooked")
minetest.register_alias("mobs:cheese", "mobs:rat_cooked")
minetest.register_alias("mobs:cheeseblock", "default:goldblock")
minetest.register_alias("mobs:meat_raw", "mobs:rat")
minetest.register_alias("mobs:meat", "mobs:rat_cooked")
minetest.register_alias("mobs:mutton", "mobs:rat_cooked")
minetest.register_alias("mobs:beef_cooked", "mobs:rat_cooked")
minetest.register_alias("mobs:mutton_cooked", "mobs:rat_cooked")
--pumba
minetest.register_alias("mobs:pork_raw", "mobs:rat")
minetest.register_alias("mobs:pork_cooked", "mobs:rat_cooked")

--lavaflan
minetest.register_alias("mobs:lava_orb", "mobs:rat_cooked")
minetest.register_alias("mobs:pick_lava", "default:pick_mese")
minetest.register_alias("mobs:pick_lava", "default:pick_mese")

minetest.register_alias("mobs:rotten_flesh", "mobs:leather")
minetest.register_alias("mobs:animal_rat", "mobs:rat")
minetest.register_alias("mobs_animal:rat", "mobs:rat")
minetest.register_alias("mobs:spawner", "mobs:cursed_stone")
minetest.register_alias("mobs:carrot_stick", "mobs:cursed_stone")
minetest.register_alias("mobs:carrotstick", "mobs:cursed_stone")
minetest.register_alias("mobs:mob_spawner", "mobs:cursed_stone")