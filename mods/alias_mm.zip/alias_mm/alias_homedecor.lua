-- mods/default/aliases_homedecor.lua

-- MASSIVE overwrite to old nodes and items merged into default


--H O M E   D E C O R--

-- Crafting for homedecor mod (includes folding) by Vanessa Ezekowitz
-- Simplified by maikerumine
-- Mostly my own code; overall template borrowed from game default



-- CRAFT ITEMS
minetest.register_alias("homedecor:brass_ingot", "default:bronze_ingot")
minetest.register_alias("homedecor:oil_extract", "default:coal_lump")
minetest.register_alias("homedecor:paraffin", "default:papyrus")
minetest.register_alias("homedecor:plastic_sheeting", "default:paper")
minetest.register_alias("homedecor:drawer_small", "default:wood")
minetest.register_alias("homedecor:ic", "default:copper_ingot")
minetest.register_alias("homedecor:heating_element", "default:steel_ingot")
minetest.register_alias("homedecor:power_crystal", "default:mese_crystal")
minetest.register_alias("homedecor:blank_canvas", "default:paper")
minetest.register_alias("mesecons_materials:silicon", "default:sand")
minetest.register_alias("homedecor:ceiling_tile", "stairs:slab_wool_white")

-- PAINTINGS 1-20
minetest.register_alias("homedecor:painting_1", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_2", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_3", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_4", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_5", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_6", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_7", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_8", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_9", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_10", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_11", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_12", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_13", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_14", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_15", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_16", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_17", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_18", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_19", "stairs:slab1_wool_white")
minetest.register_alias("homedecor:painting_20", "stairs:slab1_wool_white")

-- BATH
minetest.register_alias("homedecor:toilet", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:sink", "ts_furniture:default_wood_table")
minetest.register_alias("homedecor:taps", "stairs:slab1_diamondblock")
minetest.register_alias("homedecor:taps_brass", "stairs:slab1_goldblock")
minetest.register_alias("homedecor:shower_tray", "stairs:slab1_steelblock")
minetest.register_alias("homedecor:shower_head", "stairs:slab1_diamondblock")
minetest.register_alias("homedecor:toilet_paper", "stairs:slab1_diamondblock")
minetest.register_alias("homedecor:medicine_cabinet", "default:chest")

-- KITCHEN
minetest.register_alias("homedecor:kitchen_faucet", "stairs:slab1_diamondblock")
minetest.register_alias("homedecor:coffee_maker", "stairs:slab_copperblock")
minetest.register_alias("homedecor:barbecue", "default:furnace")
minetest.register_alias("homedecor:beer_tap", "stairs:slab_bronzeblock")
minetest.register_alias("homedecor:oven_steel", "default:furnace")
minetest.register_alias("homedecor:oven", "default:furnace")
minetest.register_alias("homedecor:microwave_oven", "default:furnace")
minetest.register_alias("homedecor:refrigerator_steel", "default:chest")
minetest.register_alias("homedecor:refrigerator_white", "default:chest")
minetest.register_alias("homedecor:kitchen_cabinet", "default:chest")
minetest.register_alias("homedecor:kitchen_cabinet_steel", "default:chest")
minetest.register_alias("homedecor:kitchen_cabinet_marble", "default:chest")
minetest.register_alias("homedecor:kitchen_cabinet_granite", "default:chest")
minetest.register_alias("homedecor:kitchen_cabinet_half", "default:chest")
minetest.register_alias("homedecor:kitchen_cabinet_with_sink", "default:chest")
minetest.register_alias("homedecor:dishwasher", "default:chest")
minetest.register_alias("homedecor:dishwasher_wood", "default:chest")
minetest.register_alias("homedecor:dishwasher_steel", "default:chest")
minetest.register_alias("homedecor:dishwasher_marble", "default:chest")
minetest.register_alias("homedecor:dishwasher_granite", "default:chest")

-- BOOK
minetest.register_alias("homedecor:book_red", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_green", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_blue", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_violet", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_grey", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_brown", "default:sign_wall_wood")

minetest.register_alias("homedecor:book_open_red", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_open_green", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_open_blue", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_open_violet", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_open_grey", "default:sign_wall_wood")
minetest.register_alias("homedecor:book_open_brown", "default:sign_wall_wood")


--CURTAIN
minetest.register_alias("homedecor:curtain", "default:sign_wall_wood")
minetest.register_alias("homedecor:curtain_red", "default:sign_wall_wood")
minetest.register_alias("homedecor:curtain_green", "default:sign_wall_wood")
minetest.register_alias("homedecor:curtain_blue", "default:sign_wall_wood")
minetest.register_alias("homedecor:curtain_violet", "default:sign_wall_wood")
minetest.register_alias("homedecor:curtain_grey", "default:sign_wall_wood")
minetest.register_alias("homedecor:curtain_brown", "default:sign_wall_wood")


--FURNATURE
minetest.register_alias("homedecor:office_chair_basic", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:chair", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:chair_black", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:chair_red", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:chair_pink", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:chair_violet", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:chair_blue", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:chair_dark_green", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:armchair", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:armchair_black", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:armchair_red", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:armchair_pink", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:armchair_violet", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:armchair_blue", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:armchair_dark_green", "ts_furniture:default_wood_chair")
minetest.register_alias("homedecor:table", "ts_furniture:default_wood_table")
minetest.register_alias("homedecor:table_mahogany", "ts_furniture:default_wood_table")
minetest.register_alias("homedecor:table_white", "ts_furniture:default_wood_table")
minetest.register_alias("homedecor:desk", "ts_furniture:default_wood_table")
minetest.register_alias("homedecor:television", "default:tinblock")





