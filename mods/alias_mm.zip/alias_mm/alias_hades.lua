--Extreme Survival created by maikerumine
-- Minetest 0.4.16 mod: "Extreme Survival"
-- namespace: es
--version 0.4.16
--https://github.com/maikerumine

--License:
--~~~~~~~~
--Code:
--(c) Copyright 2015-2020 maikerumine; modified zlib-License
--see "LICENSE.txt" for details.

--Media(if not stated differently):
--(c) Copyright (2014-2020) maikerumine; CC-BY-SA 3.0

--Alias                      "old"--->"new"
------------------------------------------
--[[
Could not load image "default_birchwood.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_black.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_blue.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_cyan.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_magenta.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_violet.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_red.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_pink.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_orange.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_brown.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_yellow.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_green.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_dark_green.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_white.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_grey.png" while building texture; Creating a dummy image
2021-09-29 02:37:37: ERROR[Main]: generateImage(): Could not load image "hades_trees_colwood_dark_grey.png" while building texture; Creating a dummy image
2021-09-29 02:37:38: WARNING[Main]: TextureSource::g

2021-09-29 02:39:56: ERROR[Server]: Item "hades_core:ladder" not defined at position (165,4,574)
2021-09-29 02:40:04: ERROR[Server]: Item "hades_core:brick_red" not defined at position (127,3,563)
2021-09-29 02:40:14: ERROR[Server]: Item "hades_torches:torch_wall" not defined at position (155,-5,581)

]]

--===========================================
--===========================================
--This is to fix the old interaction with hades mods.
--
minetest.register_alias("hades_trees:colwood_black", "cblocks:wood_black")
minetest.register_alias("hades_trees:colwood_blue", "cblocks:wood_blue")
minetest.register_alias("hades_trees:colwood_cyan", "cblocks:wood_cyan")
minetest.register_alias("hades_trees:colwood_magenta", "cblocks:wood_magenta")
minetest.register_alias("hades_trees:colwood_violet", "cblocks:wood_violet")
minetest.register_alias("hades_trees:colwood_red", "cblocks:wood_red")
minetest.register_alias("hades_trees:colwood_pink", "cblocks:wood_pink")
minetest.register_alias("hades_trees:colwood_orange", "cblocks:wood_orange")
minetest.register_alias("hades_trees:colwood_brown", "cblocks:wood_brown")
minetest.register_alias("hades_trees:colwood_yellow", "cblocks:wood_yellow")
minetest.register_alias("hades_trees:colwood_green", "cblocks:wood_green")
minetest.register_alias("hades_trees:colwood_dark_green", "cblocks:wood_dark_green")
minetest.register_alias("hades_trees:colwood_white", "cblocks:wood_white")
minetest.register_alias("hades_trees:colwood_grey", "cblocks:wood_grey")
minetest.register_alias("hades_trees:colwood_dark_grey", "cblocks:wood_dark_grey")
minetest.register_alias("hades_trees:colwood_white", "cblocks:wood_white")

minetest.register_alias("hades_core:stone", "default:stone")

minetest.register_alias("hades_core:stone_with_coal", "default:stone_with_coal")
minetest.register_alias("hades_core:stone_with_iron", "default:stone_with_iron")
minetest.register_alias("hades_core:stone_with_tin", "default:stone_with_tin")
minetest.register_alias("hades_core:stone_with_copper", "default:stone_with_copper")
minetest.register_alias("hades_core:stone_with_gold", "default:stone_with_gold")
minetest.register_alias("hades_core:stone_with_mese", "default:stone_with_mese")
minetest.register_alias("hades_core:stone_with_diamond", "default:stone_with_diamond")
minetest.register_alias("hades_core:stone_with_emerald", "es:stone_with_emeralds")
minetest.register_alias("hades_core:stone_with_sapphire", "es:stone_with_aikerums")
minetest.register_alias("hades_core:stone_with_ruby", "es:stone_with_rubys")

minetest.register_alias("hades_core:obsidianbrick", "default:obsidianbrick")
minetest.register_alias("hades_core:stonebrick", "default:stonebrick")

minetest.register_alias("hades_core:dirt_with_grass", "default:dirt_with_grass")
minetest.register_alias("hades_core:dirt", "default:dirt")
minetest.register_alias("hades_core:gravel", "default:gravel")
minetest.register_alias("hades_core:sandstone", "default:sandstone")
minetest.register_alias("hades_core:sandstonebrick", "default:sandstonebrick")
minetest.register_alias("hades_core:clay", "default:clay")
minetest.register_alias("hades_core:brick", "default:brick")

minetest.register_alias("hades_core:brick_black", "cblocks:brick_black")
minetest.register_alias("hades_core:brick_blue", "cblocks:brick_blue")
minetest.register_alias("hades_core:brick_cyan", "cblocks:brick_cyan")
minetest.register_alias("hades_core:brick_magenta", "cblocks:brick_magenta")
minetest.register_alias("hades_core:brick_violet", "cblocks:brick_violet")
minetest.register_alias("hades_core:brick_red", "cblocks:brick_red")
minetest.register_alias("hades_core:brick_pink", "cblocks:brick_pink")
minetest.register_alias("hades_core:brick_orange", "cblocks:brick_orange")
minetest.register_alias("hades_core:brick_brown", "cblocks:brick_brown")
minetest.register_alias("hades_core:brick_yellow", "cblocks:brick_yellow")
minetest.register_alias("hades_core:brick_green", "cblocks:brick_green")
minetest.register_alias("hades_core:brick_dark_green", "cblocks:brick_dark_green")
minetest.register_alias("hades_core:brick_white", "cblocks:brick_white")
minetest.register_alias("hades_core:brick_grey", "cblocks:brick_grey")
minetest.register_alias("hades_core:brick_dark_grey", "cblocks:brick_dark_grey")
minetest.register_alias("hades_core:brick_white", "cblocks:brick_white")


minetest.register_alias("hades_core:bookshelf", "default:bookshelf")
minetest.register_alias("hades_core:glass", "default:glass")
minetest.register_alias("hades_core:cobble", "default:cobble")
minetest.register_alias("hades_core:mossycobble", "default:mossycobble")

minetest.register_alias("hades_core:coalblock", "default:coalblock")
minetest.register_alias("hades_core:steelblock", "default:steelblock")
minetest.register_alias("hades_core:tinblock", "default:tinblock")
minetest.register_alias("hades_core:copperblock", "default:copperblock")
minetest.register_alias("hades_core:bronzeblock", "default:bronzeblock")
minetest.register_alias("hades_core:mese", "default:mese")
minetest.register_alias("hades_core:goldblock", "default:goldblock")

minetest.register_alias("hades_core:emerald_block", "es:emerald_block")
minetest.register_alias("hades_core:sapphire_block", "es:aikerum_block")
minetest.register_alias("hades_core:ruby_block", "es:ruby_block")

minetest.register_alias("hades_core:diamondblock", "default:diamondblock")
minetest.register_alias("hades_core:obsidian_glass", "default:obsidian_glass")
minetest.register_alias("hades_core:obsidian", "default:obsidian")
minetest.register_alias("hades_core:obsidian_block", "default:obsidian_block")
minetest.register_alias("hades_core:obsidian_block", "default:obsidian_block")



minetest.register_alias("hades_core:ladder", "default:ladder_wood")

minetest.register_alias("hades_torches:torch", "default:torch")
minetest.register_alias("hades_torches:torch_ceiling", "default:torch_ceiling")
minetest.register_alias("hades_torches:torch_wall", "default:torch_wall")


minetest.register_alias("hades_core:water_source", "default:water_source")
minetest.register_alias("hades_core:water_flowing", "default:water_flowing")
minetest.register_alias("hades_core:lava_source", "default:lava_source")
minetest.register_alias("hades_core:lava_flowing", "default:lava_flowing")


minetest.register_alias("default:birchwood", "default:aspen_wood")



minetest.register_alias("mobs_hades:cobweb", "mobs:cobweb")



--[[
fix:
flowerpots
windows

]]