-- mods/default/aliases_quartz.lua

-- MASSIVE overwrite to old nodes and items merged into default


--Q U A R T Z--
minetest.register_alias("quartz:quartz_crystal", "default:mese_crystal")
minetest.register_alias("quartz:quartz_crystal_piece", "default:mese_crystal_fragment")
minetest.register_alias("quartz:quartz_ore", "default:stone_with_mese")
minetest.register_alias("quartz:block", "default:silver_sandstone")
minetest.register_alias("quartz:chiseled", "default:silver_sandstone_brick")
minetest.register_alias("quartz:pillar", "default:silver_sandstone_block")
minetest.register_alias("quartz:pillar_horizontal", "default:silver_sandstone_block")

minetest.register_alias("stairs:stair_quartzblock", "stairs:stair_silver_sandstone" );
minetest.register_alias("stairs:slope_quartzblock", "stairs:stair_silver_sandstone" );
minetest.register_alias("stairs:slab_quartzblock", "stairs:slab_silver_sandstone");
minetest.register_alias("stairs:slab1_quartzblock", "stairs:slab_silver_sandstone");
minetest.register_alias("stairs:stair_quartz_chiseled", "stairs:stair_silver_sandstone_brick" );
minetest.register_alias("stairs:slab_quartz_chiseled", "stairs:slab_silver_sandstone_brick");
minetest.register_alias("stairs:stair_quartz_pillar", "stairs:stair_silver_sandstone_block" );
minetest.register_alias("stairs:slab_quartz_pillar", "stairs:slab_silver_sandstone_block");
minetest.register_alias("stairs:stair_quartz_pillar_horizontal", "stairs:stair_silver_sandstone_block" );
minetest.register_alias("stairs:slab_quartz_pillar_horizontal", "stairs:slab_silver_sandstone_block");

minetest.register_alias("walls:stair_block", "walls:steelblock")
minetest.register_alias("walls:pillar", "walls:steelblock")
minetest.register_alias("walls:chiseled", "walls:steelblock")


