-- mods/default/aliases_basicmachines.lua

-- MASSIVE overwrite to old nodes and items merged into default


--B A S I C   M A C H I N E S--
--[[
	local purity_table = {"33","66"};
	
	for i = 1,#purity_table do
		local purity = purity_table[i];
		minetest.register_craftitem("basic_machines:"..name.."_dust_".. purity, {
			description = name.. " dust purity " .. purity .. "%" ,
			inventory_image = "basic_machines_dust.png^[colorize:#"..R..G..B..":180",
		})
	end
	]]

--CRAFT ITEMS
--emerald_dust
--ruby_dust
--aikerum_dust
--purpellium_dust

minetest.register_alias("basic_machines:steel_dust_33", "es:emerald_dust")
minetest.register_alias("basic_machines:steel_dust_66", "es:cookable_emerald_ingot")

minetest.register_alias("basic_machines:gold_dust_33", "es:emerald_dust")
minetest.register_alias("basic_machines:gold_dust_66", "es:cookable_emerald_ingot")

minetest.register_alias("basic_machines:diamond_dust_33", "es:emerald_dust")
minetest.register_alias("basic_machines:diamond_dust_66", "es:cookable_emerald_ingot")

minetest.register_alias("basic_machines:mese_dust_33", "es:emerald_dust")
minetest.register_alias("basic_machines:mese_dust_66", "es:cookable_emerald_ingot")

minetest.register_alias("basic_machines:emerald_dust_33", "es:emerald_dust")
minetest.register_alias("basic_machines:emerald_dust_66", "es:cookable_emerald_ingot")

minetest.register_alias("basic_machines:ruby_dust_33", "es:ruby_dust")
minetest.register_alias("basic_machines:ruby_dust_66", "es:cookable_ruby_ingot")

minetest.register_alias("basic_machines:aikerum_dust_33", "es:aikerum_dust")
minetest.register_alias("basic_machines:aikerum_dust_66", "es:cookable_aikerum_ingot")

minetest.register_alias("basic_machines:purpellium_dust_33", "es:purpellium_dust")
minetest.register_alias("basic_machines:purpellium_dust_66", "es:cookable_purpellium_ingot")




minetest.register_alias("basic_machines:charcoal", "default:coal_lump")

--BLOCKS
minetest.register_alias("basic_machines:light_on", "default:meselamp")
minetest.register_alias("basic_machines:light_off", "default:meselamp")

minetest.register_alias("basic_machines:autocrafter", "default:chest_locked")
minetest.register_alias("basic_machines:ball", "default:copperblock")
minetest.register_alias("basic_machines:ball_spawner", "default:copperblock")
minetest.register_alias("basic_machines:enviro", "default:copperblock")
minetest.register_alias("basic_machines:grinder", "default:chest_locked")


minetest.register_alias("basic_machines:keypad", "default:obsidian")
minetest.register_alias("basic_machines:mover", "default:chest_locked")
minetest.register_alias("basic_machines:detector", "default:tinblock")
minetest.register_alias("basic_machines:distributor", "default:goldblock")
minetest.register_alias("basic_machines:clockgen", "default:diamondblock")
minetest.register_alias("basic_machines:recycler", "default:chest_locked")

minetest.register_alias("basic_machines:battery", "default:chest_locked")
minetest.register_alias("basic_machines:battery_0", "default:chest_locked")
minetest.register_alias("basic_machines:battery_1", "default:chest_locked")
minetest.register_alias("basic_machines:battery_2", "default:chest_locked")
minetest.register_alias("basic_machines:battery_3", "default:chest_locked")
minetest.register_alias("basic_machines:generator", "default:chest_locked")
minetest.register_alias("basic_machines:power_cell", "default:diamondblock")
minetest.register_alias("basic_machines:power_block", "default:goldblock")
minetest.register_alias("basic_machines:power_rod", "default:mese")




