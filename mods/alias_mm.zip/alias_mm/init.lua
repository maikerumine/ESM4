--maikerumines alias tool

alias_mm = {}

local modpath = minetest.get_modpath("alias_mm")

alias_mm.modpath = modpath

dofile(modpath.."/alias.lua")
dofile(modpath.."/alias_army.lua")
dofile(modpath.."/alias_cottages.lua")
dofile(modpath.."/alias_basicmachines.lua")
dofile(modpath.."/alias_farming.lua")
dofile(modpath.."/alias_homedecor.lua")
dofile(modpath.."/alias_mesecrystals.lua")
dofile(modpath.."/alias_mobs.lua")
dofile(modpath.."/alias_moreblocks.lua")
dofile(modpath.."/alias_moretrees.lua")
dofile(modpath.."/alias_nsspf.lua")
dofile(modpath.."/alias_plantlife.lua")
dofile(modpath.."/alias_quartz.lua")
dofile(modpath.."/alias_stairs.lua")
dofile(modpath.."/alias_technic.lua")