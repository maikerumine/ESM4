-- mods/default/alias_cottages.lua

-- MASSIVE overwrite to old nodes and items merged into default


--F A R M I N G--

minetest.register_alias("cottages:hammer", "default:pick_steel" );
minetest.register_alias("cottages:anvil", "default:tinblock" );

minetest.register_alias("stairs:stair_loam", "stairs:stair_tree" );
minetest.register_alias("stairs:slab_loam", "stairs:slab_tree" );



minetest.register_alias("cottages:roof_wood", "stairs:stair_tree" );
minetest.register_alias("cottages:roof_connector_wood", "stairs:stair_tree");
minetest.register_alias("cottages:roof_flat_wood", "stairs:slab_tree");

minetest.register_alias("cottages:roof_black", "stairs:stair_obsidian");
minetest.register_alias("cottages:roof_connector_black", "stairs:stair_obsidian");
minetest.register_alias("cottages:roof_flat_black", "stairs:slab_obsidian");

minetest.register_alias("cottages:roof_red", "stairs:stair_desert_stone_block");
minetest.register_alias("cottages:roof_connector_red", "stairs:stair_desert_stone_block");
minetest.register_alias("cottages:roof_flat_red", "stairs:slab_desert_stone_block");

minetest.register_alias("cottages:roof_brown", "stairs:stair_junglewood");
minetest.register_alias("cottages:roof_connector_brown", "stairs:stair_junglewood");
minetest.register_alias("cottages:roof_flat_brown", "stairs:slab_junglewood");

minetest.register_alias("cottages:slate", "stairs:stair_stone_block");
minetest.register_alias("cottages:roof_slate", "stairs:stair_stone_block");
minetest.register_alias("cottages:roof_connector_slate", "stairs:stair_stone_block");
minetest.register_alias("cottages:roof_flat_slate", "stairs:slab_stone_block");

minetest.register_alias("cottages:reet", "stairs:stair_jungletree");
minetest.register_alias("cottages:roof_reet", "stairs:stair_jungletree");
minetest.register_alias("cottages:roof_connector_reet", "stairs:stair_jungletree");
minetest.register_alias("cottages:roof_flat_reet", "stairs:slab_jungletree");

--farming:straw
minetest.register_alias("cottages:roof_straw", "stairs:stair_straw");
minetest.register_alias("cottages:roof_connector_straw", "stairs:stair_straw");
minetest.register_alias("cottages:roof_flat_straw", "stairs:slab_straw");

minetest.register_alias("cottages:barrel", "default:chest");
minetest.register_alias("cottages:barrel_open", "default:chest");
minetest.register_alias("cottages:barrel_lying", "default:chest");
minetest.register_alias("cottages:barrel_lying_open", "default:chest");
minetest.register_alias("cottages:tub", "default:steelblock");
minetest.register_alias("cottages:window_shutter_open", "xpanes:pane_flat");
minetest.register_alias("cottages:window_shutter_closed", "xpanes:pane_flat");
minetest.register_alias("cottages:half_door", "doors:trapdoor");
minetest.register_alias("cottages:half_door_inverted", "doors:trapdoor");
minetest.register_alias("cottages:gate_closed", "doors:gate_wood_open");
minetest.register_alias("cottages:gate_open", "doors:gate_wood_open");
minetest.register_alias("cottages:hatch_wood", "doors:trapdoor");
minetest.register_alias("cottages:hatch_steel", "xpanes:trapdoor_steel_bar");

minetest.register_alias("cottages:fence_small", "default:fence_wood");
minetest.register_alias("cottages:fence_corner", "default:fence_wood");
minetest.register_alias("cottages:fence_end", "default:fence_wood");

minetest.register_alias("cottages:bed_foot", "beds:bed_bottom")
minetest.register_alias("cottages:bed_head", "beds:bed_top")

minetest.register_alias("cottages:sleeping_mat", "stairs:slab_straw");
minetest.register_alias("cottages:loam", "default:clay");
minetest.register_alias("cottages:slate_vertical", "default:stone_block");
minetest.register_alias("cottages:bench", "default:wood");
minetest.register_alias("cottages:table", "default:fence_wood");
minetest.register_alias("cottages:shelf", "default:chest");
minetest.register_alias("cottages:stovepipe", "walls:stone");
minetest.register_alias("cottages:washing", "default:furnace");
minetest.register_alias("cottages:wagon_wheel", "default:sign_wall_steel");
minetest.register_alias("cottages:feldweg", "default:gravel");
minetest.register_alias("cottages:straw_ground", "stairs:slab_straw");
minetest.register_alias("cottages:glass_pane", "xpanes:pane_flat");
minetest.register_alias("cottages:glass_pane_side", "xpanes:pane_flat");
minetest.register_alias("cottages:straw_mat", "stairs:slab_straw");
minetest.register_alias("cottages:straw_bale", "farming:straw");
minetest.register_alias("cottages:straw", "farming:straw");

minetest.register_alias("cottages:threshing_floor", "default:steelblock");
minetest.register_alias("cottages:handmill", "default:steelblock");

minetest.register_alias("cottages:chest_private", "default:chest_locked");
minetest.register_alias("cottages:chest_work", "default:chest");
minetest.register_alias("cottages:chest_storage", "default:chest");

minetest.register_alias("cottages:wood_flat", "stairs:slab_wood");
minetest.register_alias("cottages:wool_tent", "stairs:slab_wool_white");
minetest.register_alias("cottages:wool", "wool:white");


